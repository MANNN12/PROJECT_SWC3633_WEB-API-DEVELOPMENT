<?php
// Middleware 1: Request Logging
function logRequest(): void {
    $log = sprintf(
        "[%s] %s %s - IP: %s\n",
        date('Y-m-d H:i:s'),
        $_SERVER['REQUEST_METHOD'],
        $_SERVER['REQUEST_URI'],
        $_SERVER['REMOTE_ADDR']
    );
    file_put_contents(__DIR__ . '/api_access.log', $log, FILE_APPEND);
}

// Middleware 2: Set Headers & Centralized Error Handling
function jsonHeaders(array $allowedMethods): void {
    logRequest();
    header('Content-Type: application/json; charset=UTF-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Access-Control-Allow-Methods: ' . implode(',', $allowedMethods) . ', OPTIONS');

    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }

    set_exception_handler(function (Throwable $e): void {
        respond(500, ['error' => 'Internal Server Error: ' . $e->getMessage()]);
    });
}

function respond(int $statusCode, array $payload): void {
    http_response_code($statusCode);
    echo json_encode($payload, JSON_PRETTY_PRINT);
    exit;
}

function readJson(): array {
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true);
    if (!is_array($data) && $_SERVER['REQUEST_METHOD'] !== 'GET') {
        respond(400, ['error' => 'Invalid JSON body payload']);
    }
    return $data ?? [];
}

function validId(mixed $value): ?int {
    $id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    return $id === false ? null : $id;
}

// Middleware 3: JWT Authentication & Role Validation
function authenticateToken(): array {
    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';

    if (!preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
        respond(401, ['error' => 'Access denied. Missing Authorization Token']);
    }

    $jwt = $matches[1];
    $tokenParts = explode('.', $jwt);
    if (count($tokenParts) !== 3) {
        respond(401, ['error' => 'Invalid JWT token format']);
    }

    $payload = json_decode(base64_decode($tokenParts[1]), true);
    if (!$payload || !isset($payload['exp']) || $payload['exp'] < time()) {
        respond(401, ['error' => 'JWT Token has expired or is invalid']);
    }

    return $payload;
}

function authorizeRoles(array $allowedRoles, array $userPayload): void {
    if (!in_array($userPayload['role'], $allowedRoles)) {
        respond(403, ['error' => 'Forbidden. Insufficient permissions for this action']);
    }
}

function generateQRCode(string $content): string {
    return "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" . urlencode($content);
}