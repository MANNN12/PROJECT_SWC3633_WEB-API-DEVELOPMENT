-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 16, 2026 at 10:41 AM
-- Server version: 8.4.3
-- PHP Version: 8.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sportsphere_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','organiser','staff','customer') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'customer',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'System Administrator', 'admin@sportsphere.com', '$2y$10$eSUtyrlXo6IADbU7A5vmuOfEN/c/H56V14uDE4mlZBwHmBxII83jS', 'admin', '2026-10-10 05:16:05'),
(2, 'UPTM Futsal Club', 'futsal@uptm.edu.my', '$2y$10$QoFpBiOL3wtvJC2R2dp1B.kl4EI7WKtcywPYZt4Cc2yEuX8reEfRO', 'organiser', '2026-10-10 05:16:05'),
(3, 'Finance Officer', 'finance@sportsphere.com', '$2y$10$/QiPpHS4YWc1T8MsTzPbZOT92GoHKIrrE7ymE80Zx1s9gkxCo8zAi', 'staff', '2026-10-10 05:16:05'),
(4, 'Abbas', 'abbas@gmail.com', '$2y$10$xl2CHjlRiWa6LkwgO0TyXe7l5Umvh3YHJry4E2tmkfJTSrePCe2va', 'customer', '2026-10-10 05:16:05'),
(5, 'Piji', 'piji@gmail.com', '$2y$10$7lTIO.g9b7PYXSLO7nrlKuQ3u5oHX1V/U68IiW2sAM1XFXwCtb5AG', 'customer', '2026-10-10 05:16:05'),
(7, 'Aiman', 'aiman@gmail.com', '$2y$10$mQwzavagfvF6Rf484KesR.aLdjuZZih4uO2bwjizT/0xOTCSxscrG', 'customer', '2026-10-16 10:36:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
