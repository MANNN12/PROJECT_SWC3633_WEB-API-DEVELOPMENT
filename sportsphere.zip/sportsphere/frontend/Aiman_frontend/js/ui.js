export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const rm = n => 'RM ' + (Number(n) || 0).toFixed(2);
export const initials = n => String(n || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
export const today = () => new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
export const fdate = d => { const t = new Date(String(d).slice(0, 10) + 'T00:00:00'); return isNaN(t) ? '—' : t.toLocaleDateString('en-MY', { day: 'numeric', month: 'short', year: 'numeric' }); };

const P = {
  home: 'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10', court: 'M3 5h18v14H3zM12 5v14M3 12h4M17 12h4', calendar: 'M4 6h16v14H4zM4 10h16M8 3v5M16 3v5',
  ticket: 'M3 8a2 2 0 002-2h14a2 2 0 002 2v2a2 2 0 000 4v2a2 2 0 00-2 2H5a2 2 0 00-2-2v-2a2 2 0 000-4zM14 6v12', card: 'M3 6h18v12H3zM3 10h18M7 15h3',
  users: 'M9 11a3 3 0 100-6 3 3 0 000 6zM3 19c0-3 3-5 6-5s6 2 6 5M17 11a2.5 2.5 0 100-5M18 14c2 .5 3 2 3 4', user: 'M12 12a4 4 0 100-8 4 4 0 000 8zM4 20c0-4 4-6 8-6s8 2 8 6',
  logout: 'M9 4H5v16h4M16 8l4 4-4 4M20 12H9', menu: 'M4 7h16M4 12h16M4 17h16', search: 'M11 18a7 7 0 100-14 7 7 0 000 14zM20 20l-4-4', chev: 'M9 6l6 6-6 6',
  plus: 'M12 5v14M5 12h14', check: 'M5 12l5 5 9-10', x: 'M6 6l12 12M18 6L6 18', eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 15a3 3 0 100-6 3 3 0 000 6z',
  eyeoff: 'M3 3l18 18M10 6a9 9 0 0112 6 9 9 0 01-3 3.5M6.5 7.5A9 9 0 002 12s4 7 10 7a9 9 0 004-1', trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13', edit: 'M4 20h4L19 9l-4-4L4 16zM13 7l4 4',
  panel: 'M4 5h16v14H4zM9 5v14', clock: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3 2', pin: 'M12 21s7-6 7-11a7 7 0 10-14 0c0 5 7 11 7 11zM12 12a2 2 0 100-4 2 2 0 000 4z', info: 'M12 21a9 9 0 100-18 9 9 0 000 18zM12 11v5M12 8h.01',
};
export const icon = (n, cls = '') => `<svg class="ic ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${P[n] || ''}"/></svg>`;
export const LOGO = `<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="16" cy="16" r="9"/><path d="M16 7c-3 3.4-3 14.6 0 18M7 16h18"/></svg>`;

const BADGES = { confirmed: 'ok', completed: 'ok', available: 'ok', pending: 'warn', cancelled: 'bad', failed: 'bad', unavailable: 'bad', 'sold out': 'bad', past: 'mute' };
export const badge = (t, kind) => `<span class="badge ${kind || BADGES[String(t).toLowerCase()] || 'mute'}">${esc(t)}</span>`;

export function toast(msg, type = 'ok') {
  const box = $('#toasts'); const el = document.createElement('div');
  el.className = 'toast ' + type; el.setAttribute('role', type === 'bad' ? 'alert' : 'status');
  el.innerHTML = icon(type === 'bad' ? 'x' : 'check') + `<span>${esc(msg)}</span>`;
  box.appendChild(el); setTimeout(() => el.remove(), type === 'bad' ? 6500 : 3800);
}
export const skeleton = (n = 3) => `<div class="skel-wrap" aria-busy="true" aria-label="Loading">${'<div class="skel"></div>'.repeat(n)}</div>`;
export const empty = (title, text = '') => `<div class="empty">${icon('info')}<b>${esc(title)}</b><p>${esc(text)}</p></div>`;
export const errorBox = (e, retry) => `<div class="empty err">${icon('x')}<b>Something went wrong</b><p>${esc(e.message || e)}</p>${retry ? '<button class="btn" data-retry>Try again</button>' : ''}</div>`;

// Native <dialog> gives us focus trapping + Esc for free.
export function modal({ title, body, actions = [], wide = false }) {
  const d = document.createElement('dialog'); d.className = 'modal' + (wide ? ' wide' : '');
  d.innerHTML = `<form method="dialog" class="m-head"><h3>${esc(title)}</h3><button class="icon-btn" aria-label="Close">${icon('x')}</button></form><div class="m-body">${body}</div>`;
  d.addEventListener('close', () => d.remove());
  document.body.appendChild(d); d.showModal();
  return d;
}
export function confirmBox({ title, text, okLabel = 'Confirm', danger = false }) {
  return new Promise(res => {
    const d = modal({ title, body: `<p>${esc(text)}</p><div class="m-foot"><button class="btn" data-no>Cancel</button><button class="btn ${danger ? 'danger' : 'primary'}" data-yes>${esc(okLabel)}</button></div>` });
    d.addEventListener('click', e => { if (e.target.closest('[data-yes]')) { res(true); d.close(); } else if (e.target.closest('[data-no]')) d.close(); });
    d.addEventListener('close', () => res(false));
  });
}
// Disables a button while an async action runs (prevents duplicate submissions).
export async function busy(btn, fn) {
  if (btn.disabled) return; const t = btn.innerHTML; btn.disabled = true; btn.innerHTML = '<span class="spin"></span>';
  try { return await fn(); } finally { if (btn.isConnected) { btn.disabled = false; btn.innerHTML = t; } }
}

// Generic table: search, filters, sortable headers, pagination.
export function dataTable(host, { cols, rows, text, filters = [], pageSize = 10, emptyMsg = 'Nothing to show yet.', extra = '' }) {
  const st = { q: '', f: {}, sort: null, dir: 1, page: 1 };
  host.innerHTML = `<div class="toolbar"><label class="search">${icon('search')}<input type="search" placeholder="Search…" aria-label="Search" data-q></label>${filters.map((f, i) => `<select aria-label="${esc(f.label)}" data-f="${i}"><option value="">${esc(f.label)}: all</option>${f.options.map(o => `<option>${esc(o)}</option>`).join('')}</select>`).join('')}${extra}</div><div class="tbl-wrap"></div><div class="pager"></div>`;
  const wrap = $('.tbl-wrap', host), pager = $('.pager', host);
  const draw = () => {
    let r = rows.filter(x => (!st.q || text(x).toLowerCase().includes(st.q)) && filters.every((f, i) => !st.f[i] || String(f.get(x)).toLowerCase() === st.f[i].toLowerCase()));
    if (st.sort != null) { const g = cols[st.sort].sort; r = [...r].sort((a, b) => (g(a) > g(b) ? 1 : g(a) < g(b) ? -1 : 0) * st.dir); }
    const pages = Math.max(1, Math.ceil(r.length / pageSize)); st.page = Math.min(st.page, pages);
    const slice = r.slice((st.page - 1) * pageSize, st.page * pageSize);
    wrap.innerHTML = slice.length ? `<table><thead><tr>${cols.map((c, i) => `<th scope="col" ${c.sort ? `class="sortable" tabindex="0" data-s="${i}" aria-sort="${st.sort === i ? (st.dir > 0 ? 'ascending' : 'descending') : 'none'}"` : ''}>${esc(c.label)}${st.sort === i ? (st.dir > 0 ? ' ↑' : ' ↓') : ''}</th>`).join('')}</tr></thead><tbody>${slice.map(x => `<tr>${cols.map(c => `<td data-label="${esc(c.label)}">${c.render(x)}</td>`).join('')}</tr>`).join('')}</tbody></table>` : empty(rows.length ? 'No matches' : emptyMsg, rows.length ? 'Try changing your search or filters.' : '');
    pager.innerHTML = r.length > pageSize ? `<span>${r.length} results</span><button class="btn sm" data-p="-1" ${st.page <= 1 ? 'disabled' : ''}>Prev</button><span>${st.page} / ${pages}</span><button class="btn sm" data-p="1" ${st.page >= pages ? 'disabled' : ''}>Next</button>` : `<span>${r.length} ${r.length === 1 ? 'result' : 'results'}</span>`;
  };
  host.addEventListener('input', e => { if (e.target.matches('[data-q]')) { st.q = e.target.value.trim().toLowerCase(); st.page = 1; draw(); } });
  host.addEventListener('change', e => { if (e.target.matches('[data-f]')) { st.f[e.target.dataset.f] = e.target.value; st.page = 1; draw(); } });
  const sortBy = th => { const i = +th.dataset.s; st.dir = st.sort === i ? -st.dir : 1; st.sort = i; draw(); };
  host.addEventListener('click', e => { const th = e.target.closest('[data-s]'), p = e.target.closest('[data-p]'); if (th) sortBy(th); if (p) { st.page += +p.dataset.p; draw(); } });
  host.addEventListener('keydown', e => { const th = e.target.closest('[data-s]'); if (th && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); sortBy(th); } });
  draw();
}

// Sport-category artwork drawn in SVG (the database stores no photos).
const HUES = { futsal: 160, football: 150, badminton: 190, pickleball: 35, tennis: 75, basketball: 18, volleyball: 275 };
export function art(cat = '', big = false) {
  const h = HUES[String(cat).toLowerCase()] ?? (([...String(cat)].reduce((a, c) => a + c.charCodeAt(0), 0) * 37) % 360);
  return `<div class="art${big ? ' big' : ''}" style="--h:${h}" aria-hidden="true"><svg viewBox="0 0 200 110" preserveAspectRatio="xMidYMid slice"><g fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="1.6"><rect x="14" y="14" width="172" height="82" rx="6"/><path d="M100 14v82"/><circle cx="100" cy="55" r="18"/><path d="M14 38h22v34H14M186 38h-22v34h22"/></g></svg><span>${esc(cat || 'Sport')}</span></div>`;
}
