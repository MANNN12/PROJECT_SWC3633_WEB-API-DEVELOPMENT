const m = location.pathname.match(/^(.*?\/)frontend\/Aiman_frontend/);
export const API_BASE = m ? m[1] : '/sportsphere/';
const KEY = 'ss_aiman_session';
let session = null;

function decodePayload(token) {
  let s = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
  s += '='.repeat((4 - (s.length % 4)) % 4);
  const bytes = Uint8Array.from(atob(s), c => c.charCodeAt(0));
  return JSON.parse(new TextDecoder().decode(bytes));
}
export function loadSession() {
  try {
    const s = JSON.parse(sessionStorage.getItem(KEY) || 'null');
    if (!s) return null;
    const p = decodePayload(s.token);
    if (!p.exp || p.exp * 1000 < Date.now()) throw 0;
    session = { ...s, exp: p.exp };
  } catch { session = null; sessionStorage.removeItem(KEY); }
  return session;
}
export const getUser = () => session && session.user;
export const getExp = () => session && session.exp;
export function clearSession() { session = null; sessionStorage.removeItem(KEY); }
export function setUserName(name) {
  if (!session) return;
  session.user.name = name;
  sessionStorage.setItem(KEY, JSON.stringify({ token: session.token, user: session.user }));
}

export class ApiError extends Error {
  constructor(msg, status) { super(msg); this.status = status; }
}
// Route sequence: GET responses that arrive after the user navigated away are discarded (status -1).
let seq = 0;
export const bumpSeq = () => ++seq;
export const getSeq = () => seq;
let onAuthFail = () => {};
export const setAuthFailHandler = fn => { onAuthFail = fn; };

async function req(path, { method = 'GET', body, auth = false, query } = {}) {
  const my = seq;
  const url = new URL(API_BASE + path, location.origin);
  if (query) Object.entries(query).forEach(([k, v]) => v != null && url.searchParams.set(k, v));
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (auth) {
    if (!session) throw new ApiError('Please sign in to continue.', 401);
    headers.Authorization = 'Bearer ' + session.token;
  }
  let res;
  try { res = await fetch(url, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined }); }
  catch { throw new ApiError('Cannot reach the SportSphere server. Check that Apache and MySQL are running in XAMPP.', 0); }
  const text = await res.text();
  if (method === 'GET' && my !== seq) throw new ApiError('Navigation changed', -1);
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { /* PHP warning / non-JSON */ }
  if (!res.ok) {
    if (res.status === 401 && auth) onAuthFail();
    throw new ApiError((data && data.error) || (data === null ? 'The server returned an unexpected response.' : 'Request failed (' + res.status + ').'), res.status);
  }
  if (data === null) throw new ApiError('The server returned an unexpected (non-JSON) response.', res.status);
  return data;
}

export async function login(email, password) {
  const d = await req('auth.php', { method: 'POST', body: { email, password } });
  session = { token: d.token, user: d.user, exp: decodePayload(d.token).exp };
  sessionStorage.setItem(KEY, JSON.stringify({ token: d.token, user: d.user }));
  return d.user;
}

const A = { auth: true };
export const api = {
  venues: () => req('venues.php').then(d => d.data),
  createVenue: b => req('venues.php', { method: 'POST', body: b, ...A }),
  updateVenue: (id, b) => req('venues.php', { method: 'PUT', body: b, query: { id }, ...A }),
  deleteVenue: id => req('venues.php', { method: 'DELETE', query: { id }, ...A }),
  events: () => req('events.php').then(d => d.data),
  createEvent: b => req('events.php', { method: 'POST', body: b, ...A }),
  updateEvent: (id, b) => req('events.php', { method: 'PUT', body: b, query: { id }, ...A }),
  deleteEvent: id => req('events.php', { method: 'DELETE', query: { id }, ...A }),
  bookings: () => req('bookings.php').then(d => d.data),
  createBooking: b => req('bookings.php', { method: 'POST', body: b, ...A }),
  setBookingStatus: (id, status) => req('bookings.php', { method: 'PUT', body: { status }, query: { id }, ...A }),
  deleteBooking: id => req('bookings.php', { method: 'DELETE', query: { id }, ...A }),
  payments: () => req('payments.php', A).then(d => d.data),
  pay: b => req('payments.php', { method: 'POST', body: b, ...A }),
  users: () => req('users.php', { query: { page: 1, limit: 500 } }).then(d => d.data),
  register: b => req('users.php', { method: 'POST', body: b }),
  updateUser: (id, b) => req('users.php', { method: 'PUT', body: b, query: { id }, ...A }),
  deleteUser: id => req('users.php', { method: 'DELETE', query: { id }, ...A }),
};

// Customers cannot read payments.php (admin/staff only). We keep the receipt of each payment made in
// THIS browser so the UI can show "paid". Per-viewer convenience only; not shared across devices.
const pk = uid => 'ss_aiman_paid_' + uid;
export const paidMap = uid => { try { return JSON.parse(localStorage.getItem(pk(uid)) || '{}'); } catch { return {}; } };
export function rememberPayment(uid, bookingId, rec) {
  try { const m = paidMap(uid); m[bookingId] = rec; localStorage.setItem(pk(uid), JSON.stringify(m)); } catch { /* storage unavailable */ }
}
