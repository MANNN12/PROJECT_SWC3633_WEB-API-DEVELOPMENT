import { loadSession, getUser, clearSession, setAuthFailHandler, bumpSeq, getSeq } from './api.js';
import { $, $$, esc, icon, LOGO, initials } from './ui.js';
import * as P from './pages.js';

const root = $('#root');
const ALL = ['customer', 'organiser', 'staff', 'admin'];
// Frontend role gating is a UX convenience only. The PHP backend is the real authority.
const ROUTES = {
  '/dashboard': { roles: ALL, title: 'Dashboard', page: P.dashboard },
  '/venues': { roles: ALL, title: 'Venues', page: P.venuesPage },
  '/events': { roles: ALL, title: 'Events', page: P.eventsPage },
  '/bookings': { roles: ['customer'], title: 'My bookings', page: P.myBookings },
  '/manage/bookings': { roles: ['staff', 'admin'], title: 'Bookings', page: P.manageBookings },
  '/manage/venues': { roles: ['staff', 'admin'], title: 'Manage venues', page: P.manageVenues },
  '/manage/events': { roles: ['organiser', 'admin'], title: 'Manage events', page: P.manageEvents },
  '/payments': { roles: ['staff', 'admin'], title: 'Payments', page: P.paymentsPage },
  '/users': { roles: ['admin'], title: 'Users', page: P.usersPage },
  '/profile': { roles: ALL, title: 'Profile', page: P.profilePage },
};
const NAV = {
  customer: [['Explore', [['/dashboard', 'Home', 'home'], ['/venues', 'Venues', 'court'], ['/events', 'Events', 'calendar']]], ['My activity', [['/bookings', 'My bookings', 'ticket']]]],
  organiser: [['Overview', [['/dashboard', 'Dashboard', 'home']]], ['Events', [['/manage/events', 'My events', 'calendar'], ['/events', 'All events', 'ticket']]], ['Browse', [['/venues', 'Venues', 'court']]]],
  staff: [['Overview', [['/dashboard', 'Dashboard', 'home']]], ['Operations', [['/manage/bookings', 'Bookings', 'ticket'], ['/payments', 'Payments', 'card'], ['/manage/venues', 'Venues', 'court']]], ['Browse', [['/events', 'Events', 'calendar']]]],
  admin: [['Overview', [['/dashboard', 'Overview', 'home']]], ['Management', [['/users', 'Users', 'users'], ['/manage/venues', 'Venues', 'court'], ['/manage/events', 'Events', 'calendar']]], ['Operations', [['/manage/bookings', 'Bookings', 'ticket'], ['/payments', 'Payments', 'card']]]],
};
const path = () => (location.hash.slice(1) || '/').split('?')[0];
export const go = p => { if (path() === p) route(); else location.hash = p; };
let shellFor = null, notice = '';

function buildShell(user) {
  const collapsed = localStorage.getItem('ss_aiman_collapsed') === '1';
  document.body.classList.toggle('collapsed', collapsed);
  const nav = NAV[user.role].map(([g, items]) => `<div class="nav-group"><span class="nav-label">${esc(g)}</span>${items.map(([p, l, i]) => `<a href="#${p}" data-path="${p}" title="${esc(l)}">${icon(i)}<span>${esc(l)}</span></a>`).join('')}</div>`).join('');
  root.innerHTML = `<div class="shell"><aside class="sidebar" id="sidebar" aria-label="Main navigation"><a class="brand" href="#/dashboard"><span class="mark">${LOGO}</span><span class="bt">SportSphere<small>${esc(user.role)} workspace</small></span></a><nav class="nav">${nav}</nav>
    <div class="side-foot"><a href="#/profile" data-path="/profile" title="Profile">${icon('user')}<span>Profile</span></a><button id="lo" title="Sign out">${icon('logout')}<span>Sign out</span></button></div></aside><div class="scrim" id="scrim"></div>
    <div class="main"><header class="topbar"><button class="icon-btn mbtn" id="mo" aria-label="Open menu" aria-controls="sidebar">${icon('menu')}</button><button class="icon-btn dbtn" id="co" aria-label="Collapse sidebar" aria-pressed="${collapsed}">${icon('panel')}</button>
    <div class="crumbs" id="crumbs"></div><div class="grow"></div><div class="dd"><button class="user-btn" id="ub" aria-haspopup="menu" aria-expanded="false"><span class="avatar">${esc(initials(user.name))}</span><span class="un"><b>${esc(user.name)}</b><small>${esc(user.role)}</small></span></button><div class="dd-menu" id="um" role="menu" hidden><a role="menuitem" href="#/profile">${icon('user')} Profile</a><button role="menuitem" id="lo2">${icon('logout')} Sign out</button></div></div></header>
    <main class="content" id="main" tabindex="-1"></main></div></div>`;
  shellFor = user.id;
  const open = v => document.body.classList.toggle('nav-open', v);
  $('#mo').onclick = () => { open(true); $('#sidebar a').focus(); };
  $('#scrim').onclick = () => open(false);
  $('#co').onclick = e => { const c = document.body.classList.toggle('collapsed'); localStorage.setItem('ss_aiman_collapsed', c ? '1' : '0'); e.currentTarget.setAttribute('aria-pressed', c); };
  const um = $('#um'), ub = $('#ub'), tgl = v => { um.hidden = !v; ub.setAttribute('aria-expanded', v); };
  ub.onclick = e => { e.stopPropagation(); tgl(um.hidden); };
  if (!window.__ssBound) { window.__ssBound = true;
    document.addEventListener('click', e => { const m = $('#um'); if (m && !e.target.closest('.dd')) { m.hidden = true; $('#ub').setAttribute('aria-expanded', 'false'); } });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') { const m = $('#um'); if (m) m.hidden = true; document.body.classList.remove('nav-open'); } }); }
  um.onclick = () => tgl(false);
  $('#lo').onclick = $('#lo2').onclick = logout;
}
function logout(msg = '') { clearSession(); shellFor = null; notice = typeof msg === 'string' ? msg : ''; document.body.classList.remove('nav-open'); if (location.hash !== '#/login') location.hash = '#/login'; else route(); }

async function route() {
  const mySeq = bumpSeq();
  const user = getUser(), p = path();
  if (!user) {
    document.body.classList.add('is-auth'); shellFor = null;
    const mode = p === '/register' ? 'register' : 'login';
    if (p !== '/login' && p !== '/register') { location.hash = '#/login'; return; }
    P.authPage(root, mode, u => { notice = ''; location.hash = '#/dashboard'; }, notice); notice = ''; document.title = (mode === 'register' ? 'Sign up' : 'Sign in') + ' · SportSphere'; return;
  }
  document.body.classList.remove('is-auth');
  if (p === '/login' || p === '/register' || p === '/') { location.hash = '#/dashboard'; return; }
  if (shellFor !== user.id) buildShell(user);
  document.body.classList.remove('nav-open');
  const r = ROUTES[p], main = $('#main');
  $$('.sidebar a').forEach(a => { const on = a.dataset.path === p; a.classList.toggle('active', on); on ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'); });
  const title = !r ? 'Not found' : r.roles.includes(user.role) ? r.title : 'Access restricted';
  $('#crumbs').innerHTML = `<span>SportSphere</span>${icon('chev', 'sm')}<h2>${esc(title)}</h2>`; document.title = title + ' · SportSphere';
  if (!r || !r.roles.includes(user.role)) {
    main.innerHTML = `<div class="empty big">${icon('info')}<b>${r ? 'Not available for your role' : 'Page not found'}</b><p>${r ? 'Your account type does not have access to this page.' : 'That page does not exist.'}</p><a class="btn primary" href="#/dashboard">Back to dashboard</a></div>`; return;
  }
  const ctx = { user, go, refresh: () => { if (getSeq() === mySeq) return r.page(main, ctx); }, shell: () => { shellFor = null; route(); } };
  main.onclick = main.oninput = main.onchange = null; window.scrollTo(0, 0);
  await r.page(main, ctx);
}

setAuthFailHandler(() => logout('Your session expired. Please sign in again.'));
loadSession();
window.addEventListener('hashchange', route);
route();
