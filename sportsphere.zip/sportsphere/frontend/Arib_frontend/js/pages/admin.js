import { icon } from '../core/icons.js';
import { esc, rm, num, fmtDate, badge, pageHead, statCard, mountTable, errorState, skelRows, openModal, closeModal, confirmDialog, toast, withBusy, initials, cap, $ } from '../core/ui.js';
import { api } from '../core/api.js';
import { bookingTitle } from './bookings.js';
import { bookingThumb, bookingBanner, mediaCell } from '../core/venues.js';

const sum = (a, f) => a.reduce((s, x) => s + (Number(f(x)) || 0), 0);
const fail = (ctx, title, e) => { if (ctx.alive()) ctx.el.innerHTML = pageHead(title) + `<div class="card">${errorState(e.message)}</div>`; };

/* ================= PAYMENTS (staff, admin) — read-only ================= */
export async function paymentsPage(ctx) {
  const { el } = ctx;
  el.innerHTML = pageHead('Payments', 'Transactions recorded against bookings.') + `<div class="card">${skelRows(6)}</div>`;
  let pay, bks;
  try { [pay, bks] = await Promise.all([api.payments(), api.bookings()]); } catch (e) { return fail(ctx, 'Payments', e); }
  if (!ctx.alive()) return;
  const bk = Object.fromEntries(bks.map(b => [b.id, b]));
  const done = pay.filter(p => p.payment_status === 'completed');
  el.innerHTML = pageHead('Payments', 'Transactions recorded against bookings.') +
    `<div class="grid grid-stats">${statCard('Collected', rm(sum(done, p => p.amount)), 'wallet', 'green', `${done.length} completed`)}${statCard('Pending', rm(sum(pay.filter(p => p.payment_status === 'pending'), p => p.amount)), 'clock', 'amber', `${pay.filter(p => p.payment_status === 'pending').length} transactions`)}${statCard('Failed', rm(sum(pay.filter(p => p.payment_status === 'failed'), p => p.amount)), 'alert', 'red', `${pay.filter(p => p.payment_status === 'failed').length} transactions`)}${statCard('Transactions', num(pay.length), 'card')}</div><div class="card" id="tbl"></div>`;
  const byId = Object.fromEntries(pay.map(p => [p.id, p]));
  mountTable($('#tbl', el), {
    rows: pay, pageSize: 10, searchPlaceholder: 'Search reference, booking or customer…', emptyTitle: 'No payments', emptyText: 'Payments will appear here once customers pay for bookings.',
    searchText: p => `${p.transaction_ref} ${p.booking_id} ${(bk[p.booking_id] || {}).customer_name || ''} ${bk[p.booking_id] ? bookingTitle(bk[p.booking_id]) : ''}`,
    filters: [{ label: 'Status', options: ['completed', 'pending', 'failed'], get: p => p.payment_status }, { label: 'Method', options: ['fpx', 'card', 'e-wallet'], get: p => p.payment_method }],
    columns: [
      { label: 'Reference', sort: p => p.transaction_ref, render: p => `<div class="cell-main">${esc(p.transaction_ref)}</div><div class="cell-sub">#${p.id}</div>` },
      { label: 'Booking', sort: p => Number(p.booking_id), render: p => { const b = bk[p.booking_id]; const sub = `#${p.booking_id}${b ? ' · ' + esc(b.customer_name || '') : ' · booking no longer exists'}`; return b ? mediaCell(bookingThumb(b), esc(bookingTitle(b)), sub) : `<div class="cell-main">Booking #${p.booking_id}</div><div class="cell-sub">${sub}</div>`; } },
      { label: 'Method', sort: p => p.payment_method, render: p => badge(p.payment_method.toUpperCase(), 'plain') },
      { label: 'Amount', cls: 'num', sort: p => Number(p.amount), render: p => rm(p.amount) },
      { label: 'Status', sort: p => p.payment_status, render: p => badge(p.payment_status) },
      { label: 'Date', sort: p => p.created_at, render: p => fmtDate(p.created_at) },
      { label: '', cls: 'num', render: p => `<button class="btn btn-ghost btn-sm" data-view="${p.id}">Details</button>` },
    ],
  });
  el.addEventListener('click', e => {
    const v = e.target.closest('[data-view]'); if (!v) return;
    const p = byId[v.dataset.view], b = bk[p.booking_id];
    const rows = [['Reference', esc(p.transaction_ref)], ['Status', badge(p.payment_status)], ['Method', esc(p.payment_method.toUpperCase())], ['Amount', rm(p.amount)], ['Recorded', fmtDate(p.created_at)], ['Booking', '#' + p.booking_id], ...(b ? [['Item', esc(bookingTitle(b))], ['Customer', esc(b.customer_name || '—')], ['Booking total', rm(b.total_price)], ['Booking status', badge(b.status)]] : [['Item', '<span class="muted">Booking no longer exists</span>']])];
    openModal({ title: 'Payment details', body: `${b ? bookingBanner(b) : ''}<dl class="dl">${rows.map(([k, x]) => `<dt>${k}</dt><dd>${x}</dd>`).join('')}</dl><p class="field-hint mt">Payments are read-only here: the server exposes no endpoint to edit or refund a payment.</p>`, footer: '<button class="btn btn-ghost" data-close>Close</button>' });
  });
}

/* ================= USERS (admin) ================= */
const ROLES = ['customer', 'organiser', 'staff', 'admin'];
function userModal(u, onSaved) {
  const edit = !!u;
  const fld = (id, label, inner) => `<div class="field"><label for="${id}">${label}</label>${inner}<div class="field-error" data-err="${id}"></div></div>`;
  const body = `<form novalidate>${fld('un', 'Full name', `<input class="input" id="un" maxlength="100" value="${esc(u ? u.name : '')}" required>`)}
    ${edit ? fld('ue', 'Email', `<input class="input" id="ue" value="${esc(u.email)}" disabled>`) : fld('ue', 'Email', '<input class="input" id="ue" type="email" maxlength="100" required>')}
    ${edit ? '' : fld('up', 'Temporary password', '<input class="input" id="up" type="text" autocomplete="off" required>')}
    ${fld('ur', 'Role', `<select class="select" id="ur">${ROLES.map(r => `<option value="${r}" ${u && u.role === r ? 'selected' : ''}>${cap(r)}</option>`).join('')}</select>`)}</form>
    ${edit ? '<p class="field-hint">Email and password cannot be changed through the existing API.</p>' : ''}`;
  const root = openModal({ title: edit ? 'Edit user' : 'Add user', body, footer: `<button class="btn btn-ghost" data-close>Cancel</button><button class="btn" id="us">${edit ? 'Save changes' : 'Create user'}</button>` });
  $('#us', root).onclick = ev => {
    root.querySelectorAll('[data-err]').forEach(n => (n.textContent = ''));
    const name = $('#un', root).value.trim(), role = $('#ur', root).value;
    const email = edit ? '' : $('#ue', root).value.trim(), pw = edit ? '' : $('#up', root).value;
    let ok = true;
    const bad = (id, m) => { $(`[data-err=${id}]`, root).textContent = m; ok = false; };
    if (name.length < 2) bad('un', 'Enter a name.');
    if (!edit && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) bad('ue', 'Enter a valid email.');
    if (!edit && pw.length < 6) bad('up', 'Use at least 6 characters.');
    if (!ok) return;
    return withBusy(ev.currentTarget, async () => {
      try {
        if (edit) await api.updateUser(u.id, { name, role }); else await api.register({ name, email, password: pw, role });
        closeModal(); toast(edit ? 'User updated' : 'User created', 'success'); onSaved();
      } catch (x) { toast(x.message, 'error'); }
    });
  };
}

export async function usersPage(ctx) {
  const { el, user } = ctx;
  let byId = {};
  const load = async () => {
    el.innerHTML = pageHead('Users', 'Accounts and role assignments.') + `<div class="card">${skelRows(6)}</div>`;
    let rows; try { rows = await api.users(); } catch (e) { return fail(ctx, 'Users', e); }
    if (!ctx.alive()) return;
    byId = Object.fromEntries(rows.map(u => [u.id, u]));
    el.innerHTML = pageHead('Users', 'Accounts and role assignments.', `<button class="btn" id="add">${icon('plus', 'i-sm')} Add user</button>`) +
      `<div class="grid grid-stats">${ROLES.map((r, i) => statCard(cap(r) + 's', num(rows.filter(u => u.role === r).length), ['user', 'calendar', 'shield', 'users'][i], ['', '', 'amber', 'green'][i])).join('')}</div><div class="card" id="tbl"></div>`;
    mountTable($('#tbl', el), {
      rows, pageSize: 10, searchPlaceholder: 'Search name or email…', searchText: u => `${u.name} ${u.email} ${u.role}`, emptyTitle: 'No users', emptyText: 'No accounts found.',
      filters: [{ label: 'Role', options: ROLES, get: u => u.role }],
      columns: [
        { label: 'User', sort: u => u.name, render: u => `<div style="display:flex;gap:12px;align-items:center"><span class="avatar" style="width:34px;height:34px;font-size:13px">${esc(initials(u.name))}</span><div><div class="cell-main">${esc(u.name)}${Number(u.id) === Number(user.id) ? ' <span class="muted">(you)</span>' : ''}</div><div class="cell-sub">${esc(u.email)}</div></div></div>` },
        { label: 'Role', sort: u => u.role, render: u => badge(u.role) },
        { label: 'Joined', sort: u => u.created_at, render: u => fmtDate(u.created_at) },
        { label: '', cls: 'num', render: u => `<div class="row-actions"><button class="btn btn-ghost btn-sm" data-edit="${u.id}">${icon('edit', 'i-sm')} Edit</button>${Number(u.id) !== Number(user.id) ? `<button class="icon-btn" style="width:30px;height:30px" data-del="${u.id}" aria-label="Delete ${esc(u.name)}">${icon('trash', 'i-sm')}</button>` : ''}</div>` },
      ],
    });
  };
  el.addEventListener('click', async e => {
    if (e.target.closest('#add')) return userModal(null, load);
    const ed = e.target.closest('[data-edit]'), d = e.target.closest('[data-del]');
    if (ed) userModal(byId[ed.dataset.edit], load);
    if (d) {
      const u = byId[d.dataset.del];
      if (!(await confirmDialog({ title: 'Delete user?', message: `${u.name} will be deleted along with their bookings and payment records.`, confirmLabel: 'Delete user', danger: true }))) return;
      await withBusy(d, async () => { try { await api.deleteUser(u.id); toast('User deleted', 'success'); await load(); } catch (x) { toast(x.message, 'error'); } });
    }
  });
  await load();
}
