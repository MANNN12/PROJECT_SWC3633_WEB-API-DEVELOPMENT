import { icon } from '../core/icons.js';
import { LINES, esc, rm, num, fmtDate, parseDate, isUpcoming, badge, pageHead, statCard, donut, bars, emptyState, errorState, skelStats, toast, withBusy, confirmDialog, $ } from '../core/ui.js';
import { api } from '../core/api.js';
import { bookingTitle, qtyLabel, getReceipts, openBookingDetail, openPayModal } from './bookings.js';
import { venueMedia, bookingThumb } from '../core/venues.js';

const sum = (arr, f) => arr.reduce((a, x) => a + (Number(f(x)) || 0), 0);
const count = (arr, f) => arr.reduce((m, x) => { const k = f(x); m[k] = (m[k] || 0) + 1; return m; }, {});
const remaining = e => Math.max(0, Number(e.total_tickets) - Number(e.tickets_sold || 0));
const dateTile = s => { const d = parseDate(s); return `<div class="date-tile"><b>${d.getDate()}</b><span>${['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'][d.getMonth()]}</span></div>`; };
const DATA_NOTE = `<p class="field-hint" style="margin-top:18px">Figures are calculated in your browser from the records the API returned when this page loaded; they are not a live feed.</p>`;

async function guard(ctx, title, fn) {
  try { return await fn(); }
  catch (err) { if (ctx.alive()) ctx.el.innerHTML = pageHead(title) + `<div class="card">${errorState(err.message)}</div>`; return null; }
}

/* ============ CUSTOMER ============ */
export async function customerDashboard(ctx) {
  const { el, user } = ctx;
  const d = await guard(ctx, 'Dashboard', async () => { const [b, e, v] = await Promise.all([api.bookings(), api.events(), api.venues()]); return { b, e, v }; });
  if (!d || !ctx.alive()) return;
  const mine = d.b.filter(b => Number(b.customer_id) === Number(user.id));
  const live = mine.filter(b => b.status !== 'cancelled');
  const upcoming = live.filter(b => isUpcoming(b.booking_date)).sort((a, b) => a.booking_date.localeCompare(b.booking_date));
  const next = upcoming[0];
  const events = d.e.filter(e => isUpcoming(e.event_date)).sort((a, b) => a.event_date.localeCompare(b.event_date)).slice(0, 3);
  const venues = d.v.filter(v => Number(v.is_available) === 1).slice(0, 3);
  const history = mine.filter(b => !upcoming.includes(b)).slice(0, 5);
  const first = user.name.split(' ')[0];

  el.innerHTML = `<section class="hero">${LINES}<div><h1>Hi ${esc(first)}, ready to play?</h1><p>${next ? 'Your next booking is coming up. Need another court or a ticket for something bigger?' : 'You have nothing booked yet. Reserve a court or grab a ticket to an upcoming event.'}</p><div class="actions"><a class="btn btn-success" href="#/venues">Book a venue</a><a class="btn btn-ghost" href="#/events" style="border-color:rgba(255,255,255,.25)">Browse events</a></div></div>
    <div class="hero-next">${next ? `<small>Next up</small><div class="row">${bookingThumb(next, 'lg')}<div><b>${esc(bookingTitle(next))}</b><span>${fmtDate(next.booking_date)} · ${esc(qtyLabel(next))} · ${badge(next.status)}</span></div></div>` : `<small>Next up</small><b>No upcoming bookings</b><span>Your schedule is clear.</span>`}</div></section>
    <div class="grid grid-stats">${statCard('Total bookings', num(mine.length), 'ticket')}${statCard('Confirmed', num(mine.filter(b => b.status === 'confirmed').length), 'checkc', 'green')}${statCard('Awaiting confirmation', num(mine.filter(b => b.status === 'pending').length), 'clock', 'amber')}${statCard('Upcoming', num(upcoming.length), 'calendar', '', 'Excludes cancelled')}</div>
    <div class="split"><div class="card"><div class="card-head"><div><h3>Upcoming bookings</h3></div><a href="#/bookings">View all</a></div>
      ${upcoming.length ? `<ul class="list">${upcoming.slice(0, 5).map(b => `<li>${dateTile(b.booking_date)}${bookingThumb(b, 'hide-sm')}<div class="grow"><div class="t">${esc(bookingTitle(b))}</div><div class="s">${esc(qtyLabel(b))} · ${rm(b.total_price)}</div></div>${badge(b.status)}<button class="btn btn-ghost btn-sm" data-view="${b.id}">Details</button></li>`).join('')}</ul>` : emptyState('Nothing scheduled', 'Book a venue or an event and it will appear here.', '<a class="btn" href="#/venues">Find a venue</a>')}</div>
    <div class="card"><div class="card-head"><h3>Upcoming events</h3><a href="#/events">All events</a></div>${events.length ? `<ul class="list">${events.map(e => `<li>${dateTile(e.event_date)}<div class="grow"><div class="t">${esc(e.event_name)}</div><div class="s">${Number(e.ticket_price) === 0 ? 'Free' : rm(e.ticket_price)} · ${num(remaining(e))} left</div></div><a class="btn btn-ghost btn-sm" href="#/events/${e.id}">View</a></li>`).join('')}</ul>` : emptyState('No upcoming events', 'Check back soon.')}</div></div>
    <h3 style="margin:28px 0 14px">Available venues</h3>${venues.length ? `<div class="grid grid-cards">${venues.map(v => `<a class="card vcard" href="#/venues/${v.id}" style="text-decoration:none;color:inherit"><div class="vmedia">${venueMedia(v)}</div><div class="vbody"><h3>${esc(v.venue_name)}</h3><div class="vfoot" style="border:0;padding:0"><span class="muted">${esc(v.category)}</span><span class="price">${rm(v.hourly_rate)} <small>/ hr</small></span></div></div></a>`).join('')}</div>` : `<div class="card">${emptyState('No venues available', 'All venues are currently unavailable.')}</div>`}
    ${history.length ? `<div class="card mt"><div class="card-head"><h3>Booking history</h3><a href="#/bookings">Manage</a></div><ul class="list">${history.map(b => `<li>${bookingThumb(b)}<div class="grow"><div class="t">${esc(bookingTitle(b))}</div><div class="s">${fmtDate(b.booking_date)} · ${rm(b.total_price)}</div></div>${badge(b.status)}</li>`).join('')}</ul></div>` : ''}`;
  const byId = Object.fromEntries(mine.map(b => [b.id, b]));
  el.addEventListener('click', e => { const v = e.target.closest('[data-view]'); if (v) { const b = byId[v.dataset.view]; openBookingDetail(b, { user, receipt: getReceipts(user.id)[b.id], onPay: bb => openPayModal(bb, user, ctx.reload) }); } });
}

/* ============ ORGANISER ============ */
export async function organiserDashboard(ctx) {
  const { el, user } = ctx;
  const d = await guard(ctx, 'Organiser overview', async () => { const [b, e] = await Promise.all([api.bookings(), api.events()]); return { b, e }; });
  if (!d || !ctx.alive()) return;
  const mine = d.e.filter(e => Number(e.organiser_id) === Number(user.id));
  const ids = new Set(mine.map(e => Number(e.id)));
  const bk = d.b.filter(b => b.booking_type === 'event' && ids.has(Number(b.event_id)));
  const active = bk.filter(b => b.status !== 'cancelled');
  const upcoming = mine.filter(e => isUpcoming(e.event_date)).sort((a, b) => a.event_date.localeCompare(b.event_date));
  const sold = sum(mine, e => e.tickets_sold), cap = sum(mine, e => e.total_tickets);
  el.innerHTML = pageHead('Organiser overview', `Events published under ${user.name}.`, '<a class="btn" href="#/manage/events">Manage events</a>') +
    `<div class="grid grid-stats">${statCard('Events', num(mine.length), 'calendar', '', `${upcoming.length} upcoming`)}${statCard('Tickets booked', num(sold), 'ticket', 'green', cap ? `of ${num(cap)} total capacity` : '')}${statCard('Booked value', rm(sum(active, b => b.total_price)), 'wallet', '', 'Non-cancelled bookings')}${statCard('Pending bookings', num(bk.filter(b => b.status === 'pending').length), 'clock', 'amber', 'Awaiting staff')}</div>
    <div class="split"><div class="card"><div class="card-head"><div><h3>Ticket sales by event</h3><div class="sub">Tickets booked (cancelled excluded)</div></div></div><div class="card-pad">${mine.length ? bars(mine.map(e => ({ label: e.event_name, value: Number(e.tickets_sold), tone: Number(e.tickets_sold) >= Number(e.total_tickets) ? 'amber' : 'green' }))) : emptyState('No events yet', 'Create your first event to start selling tickets.', '<a class="btn" href="#/manage/events">Create event</a>')}</div></div>
    <div class="card"><div class="card-head"><h3>Next events</h3></div>${upcoming.length ? `<ul class="list">${upcoming.slice(0, 4).map(e => `<li>${dateTile(e.event_date)}<div class="grow"><div class="t">${esc(e.event_name)}</div><div class="s">${num(e.tickets_sold)} / ${num(e.total_tickets)} booked</div></div></li>`).join('')}</ul>` : emptyState('Nothing upcoming', 'No future events are scheduled.')}</div></div>
    <div class="card mt"><div class="card-head"><h3>Recent bookings for your events</h3></div>${bk.length ? `<ul class="list">${bk.slice(0, 6).map(b => `<li><div class="grow"><div class="t">${esc(b.customer_name || 'Customer #' + b.customer_id)}</div><div class="s">${esc(bookingTitle(b))} · ${esc(qtyLabel(b))} · ${rm(b.total_price)}</div></div>${badge(b.status)}</li>`).join('')}</ul>` : emptyState('No bookings yet', 'Bookings for your events will show up here.')}</div>${DATA_NOTE}`;
}

/* ============ STAFF ============ */
export async function staffDashboard(ctx) {
  const { el } = ctx;
  const d = await guard(ctx, 'Operations', async () => { const [b, p, v] = await Promise.all([api.bookings(), api.payments(), api.venues()]); return { b, p, v }; });
  if (!d || !ctx.alive()) return;
  const pending = d.b.filter(b => b.status === 'pending');
  const done = d.p.filter(p => p.payment_status === 'completed');
  const bkById = Object.fromEntries(d.b.map(b => [b.id, b]));
  el.innerHTML = pageHead('Operations', 'Bookings that need attention and the latest payment activity.', '<a class="btn btn-ghost" href="#/manage/bookings">All bookings</a>') +
    `<div class="grid grid-stats">${statCard('Pending bookings', num(pending.length), 'clock', 'amber', 'Waiting for confirmation')}${statCard('Collected', rm(sum(done, p => p.amount)), 'wallet', 'green', `${done.length} completed payments`)}${statCard('Pending / failed payments', `${d.p.filter(p => p.payment_status === 'pending').length} / ${d.p.filter(p => p.payment_status === 'failed').length}`, 'alert', 'red')}${statCard('Venues available', `${d.v.filter(v => Number(v.is_available) === 1).length} / ${d.v.length}`, 'court')}</div>
    <div class="split"><div class="card"><div class="card-head"><div><h3>Confirmation queue</h3><div class="sub">Confirming issues the customer's QR ticket</div></div></div>
      ${pending.length ? `<ul class="list">${pending.slice(0, 8).map(b => `<li>${bookingThumb(b)}<div class="grow"><div class="t">${esc(bookingTitle(b))}</div><div class="s">${esc(b.customer_name || '—')} · ${fmtDate(b.booking_date)} · ${rm(b.total_price)}</div></div><button class="btn btn-success btn-sm" data-st="confirmed" data-id="${b.id}">Confirm</button><button class="btn btn-danger btn-sm" data-st="cancelled" data-id="${b.id}">Cancel</button></li>`).join('')}</ul>` : emptyState('Queue is clear', 'No bookings are waiting for confirmation.')}</div>
    <div class="card"><div class="card-head"><h3>Recent payments</h3><a href="#/payments">View all</a></div>${d.p.length ? `<ul class="list">${d.p.slice(0, 6).map(p => { const b = bkById[p.booking_id]; return `<li>${b ? bookingThumb(b) : ''}<div class="grow"><div class="t">${esc(p.transaction_ref)}</div><div class="s">${b ? esc(bookingTitle(b)) : 'Booking #' + p.booking_id} · ${esc(p.payment_method)}</div></div><div style="text-align:right"><div style="font-weight:600">${rm(p.amount)}</div>${badge(p.payment_status)}</div></li>`; }).join('')}</ul>` : emptyState('No payments', 'Payments will appear here.')}</div></div>${DATA_NOTE}`;
  el.addEventListener('click', async e => {
    const b = e.target.closest('[data-st]'); if (!b) return;
    if (b.dataset.st === 'cancelled' && !(await confirmDialog({ title: 'Cancel booking?', message: `Booking #${b.dataset.id} will be marked cancelled.`, confirmLabel: 'Cancel booking', danger: true }))) return;
    await withBusy(b, async () => {
      try { await api.setBookingStatus(b.dataset.id, b.dataset.st); toast(`Booking #${b.dataset.id} ${b.dataset.st}`, 'success'); ctx.reload(); }
      catch (err) { toast(err.message, 'error'); }
    });
  });
}

/* ============ ADMIN ============ */
export async function adminDashboard(ctx) {
  const { el } = ctx;
  const d = await guard(ctx, 'Overview', async () => { const [u, v, e, b, p] = await Promise.all([api.users(), api.venues(), api.events(), api.bookings(), api.payments()]); return { u, v, e, b, p }; });
  if (!d || !ctx.alive()) return;
  const done = d.p.filter(p => p.payment_status === 'completed');
  const bs = count(d.b, b => b.status), roles = count(d.u, u => u.role), methods = {};
  done.forEach(p => { methods[p.payment_method] = (methods[p.payment_method] || 0) + Number(p.amount); });
  const top = [...d.e].sort((a, b) => Number(b.tickets_sold) - Number(a.tickets_sold)).slice(0, 5);
  el.innerHTML = pageHead('System overview', 'Users, inventory, bookings and revenue at a glance.') +
    `<div class="grid grid-stats">${statCard('Users', num(d.u.length), 'users', '', Object.entries(roles).map(([k, v]) => `${v} ${k}`).join(' · '))}${statCard('Venues', `${d.v.filter(v => Number(v.is_available) === 1).length} / ${d.v.length}`, 'court', '', 'Available / total')}${statCard('Events', num(d.e.length), 'calendar', '', `${d.e.filter(e => isUpcoming(e.event_date)).length} upcoming`)}${statCard('Completed payments', rm(sum(done, p => p.amount)), 'wallet', 'green', `${done.length} transactions`)}</div>
    <div class="grid grid-2"><div class="card"><div class="card-head"><h3>Bookings by status</h3></div><div class="card-pad">${donut([{ label: 'Confirmed', value: bs.confirmed || 0, color: '#0d9467' }, { label: 'Pending', value: bs.pending || 0, color: '#e59a1a' }, { label: 'Cancelled', value: bs.cancelled || 0, color: '#d03a3a' }])}</div></div>
    <div class="card"><div class="card-head"><div><h3>Revenue by payment method</h3><div class="sub">Completed payments only</div></div></div><div class="card-pad">${Object.keys(methods).length ? bars(Object.entries(methods).map(([k, v]) => ({ label: k.toUpperCase(), value: v })), rm) : emptyState('No completed payments', 'Revenue will chart here.')}</div></div>
    <div class="card"><div class="card-head"><div><h3>Top events by tickets booked</h3></div><a href="#/manage/events">Manage</a></div><div class="card-pad">${top.length ? bars(top.map(e => ({ label: e.event_name, value: Number(e.tickets_sold), tone: 'green' }))) : emptyState('No events', 'Nothing to chart yet.')}</div></div>
    <div class="card"><div class="card-head"><h3>Latest bookings</h3><a href="#/manage/bookings">View all</a></div>${d.b.length ? `<ul class="list">${d.b.slice(0, 5).map(b => `<li>${bookingThumb(b)}<div class="grow"><div class="t">${esc(bookingTitle(b))}</div><div class="s">${esc(b.customer_name || '—')} · ${rm(b.total_price)}</div></div>${badge(b.status)}</li>`).join('')}</ul>` : emptyState('No bookings', 'Nothing booked yet.')}</div></div>${DATA_NOTE}`;
}
