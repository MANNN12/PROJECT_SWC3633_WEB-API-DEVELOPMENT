import { icon } from '../core/icons.js';
import { esc, rm, num, fmtDate, parseDate, isUpcoming, todayISO, badge, pageHead, banner, sportArt, emptyState, errorState, skelCards, toast, withBusy, $, $$ } from '../core/ui.js';
import { api } from '../core/api.js';
import { openPayModal } from './bookings.js';
import { venueMedia, venueGallery, sportOf } from '../core/venues.js';

const isOn = v => Number(v) === 1;
const guessSport = sportOf;
const remaining = e => Math.max(0, Number(e.total_tickets) - Number(e.tickets_sold || 0));
function eventState(e) { if (!isUpcoming(e.event_date)) return 'past'; return remaining(e) === 0 ? 'sold out' : 'open'; }

/* ================= VENUES ================= */
function venueCard(v, canBook) {
  const on = isOn(v.is_available);
  return `<article class="card vcard"><div class="vmedia">${venueMedia(v)}${badge(on ? 'Available' : 'Unavailable', on ? 'available' : 'unavailable')}</div>
    <div class="vbody"><div class="vkind">${esc(v.category)}</div><h3>${esc(v.venue_name)}</h3>
    <div class="vfoot"><div class="price">${rm(v.hourly_rate)} <small>per hour</small></div>
    <div class="vbtns ${canBook && on ? '' : 'one'}"><a class="btn btn-ghost" href="#/venues/${v.id}">${icon('eye', 'i-sm')} View</a>${canBook && on ? `<a class="btn btn-soft" href="#/venues/${v.id}">Book now</a>` : ''}</div></div></div></article>`;
}

export async function venuesPage(ctx) {
  const { el, user } = ctx;
  const head = banner('Book to play', 'Courts and facilities you can reserve by the hour.', user.role === 'staff' || user.role === 'admin' ? '<a class="btn" href="#/manage/venues">Manage venues</a>' : '');
  el.innerHTML = head + `<div class="section">${skelCards(6)}</div>`;
  let venues;
  try { venues = await api.venues(); } catch (err) { if (ctx.alive()) el.innerHTML = pageHead('Venues') + `<div class="card">${errorState(err.message)}</div>`; return; }
  if (!ctx.alive()) return;
  const cats = [...new Set(venues.map(v => v.category))].sort();
  const st = { q: '', cat: '', avail: false, sort: 'name' };
  const canBook = user.role === 'customer';
  el.innerHTML = head + `
    <div class="finder"><div class="finder-in">
      <div class="finder-cell"><label for="q">Venue</label><input class="input" id="q" type="search" placeholder="Search by venue name or sport" autocomplete="off"></div>
      <div class="finder-cell"><label for="sort">Sort by</label><select class="select" id="sort"><option value="name">Name</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option></select></div>
      <div class="finder-cell check"><input type="checkbox" id="av"><label for="av">Available only</label></div>
    </div></div>
    <div class="section"><div class="section-head"><h2>Venues</h2><span class="count" id="count" aria-live="polite"></span></div>
      <div class="chips-scroll" id="cats" style="margin-bottom:18px"><button class="chip on" data-cat="">All sports</button>${cats.map(c => `<button class="chip" data-cat="${esc(c)}">${esc(c)}</button>`).join('')}</div>
      <div id="grid"></div></div>`;
  const draw = () => {
    let r = venues.filter(v => (!st.q || `${v.venue_name} ${v.category}`.toLowerCase().includes(st.q)) && (!st.cat || v.category === st.cat) && (!st.avail || isOn(v.is_available)));
    r.sort((a, b) => st.sort === 'low' ? a.hourly_rate - b.hourly_rate : st.sort === 'high' ? b.hourly_rate - a.hourly_rate : a.venue_name.localeCompare(b.venue_name));
    $('#count', el).textContent = `${r.length} venue${r.length === 1 ? '' : 's'}`;
    $('#grid', el).innerHTML = r.length ? `<div class="grid grid-cards">${r.map(v => venueCard(v, canBook)).join('')}</div>` : `<div class="card">${emptyState(venues.length ? 'No venues match' : 'No venues yet', venues.length ? 'Adjust the search or filters.' : 'Venues will appear here once they are added.')}</div>`;
  };
  el.addEventListener('input', e => { if (e.target.id === 'q') { st.q = e.target.value.trim().toLowerCase(); draw(); } });
  el.addEventListener('change', e => { if (e.target.id === 'av') { st.avail = e.target.checked; draw(); } if (e.target.id === 'sort') { st.sort = e.target.value; draw(); } });
  el.addEventListener('click', e => { const c = e.target.closest('[data-cat]'); if (c) { st.cat = c.dataset.cat; $$('#cats .chip', el).forEach(x => x.classList.toggle('on', x === c)); draw(); } });
  draw();
}

function bookingSuccess(box, r, user, kindLabel) {
  box.innerHTML = `<div class="card card-pad" style="border-color:#b7e5d2"><div class="stat-ico green" style="margin-bottom:14px">${icon('checkc')}</div><h3>Booking #${esc(r.booking_id)} created</h3>
    <p class="muted" style="margin:8px 0 16px">Your ${esc(kindLabel)} is <b>${esc(r.status)}</b>. ${r.status === 'pending' ? 'Staff will confirm it, after which a QR ticket is issued.' : ''}</p>
    <div class="actions"><button class="btn btn-success" id="pay-now">Pay now</button><a class="btn btn-ghost" href="#/bookings">View my bookings</a></div></div>`;
  $('#pay-now', box).onclick = () => openPayModal({ id: r.booking_id, total_price: r.total, booking_type: r.type, venue_name: r.name, event_name: r.name, quantity: r.qty }, user, () => { $('#pay-now', box).replaceWith(Object.assign(document.createElement('span'), { className: 'badge ok', textContent: 'Payment recorded' })); });
}

export async function venueDetail(ctx) {
  const { el, user, params } = ctx;
  el.innerHTML = skelCards(1);
  let v, bookings = [];
  try {
    v = await api.venue(params[0]);
    bookings = await api.bookings().catch(() => []); // only used for an informational day count
  } catch (err) { if (ctx.alive()) el.innerHTML = `<div class="card">${errorState(err.message, err.status !== 404)}</div>`; return; }
  if (!ctx.alive()) return;
  ctx.setTitle(v.venue_name);
  const on = isOn(v.is_available), canBook = user.role === 'customer';
  el.innerHTML = `<div class="split"><div class="card card-pad">${venueGallery(v)}<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:10px">${badge(on ? 'Available' : 'Unavailable', on ? 'available' : 'unavailable')}${badge(v.category, 'venue')}</div>
      <h1 style="font-size:28px">${esc(v.venue_name)}</h1>
      <div class="price" style="margin:12px 0 18px">${rm(v.hourly_rate)} <small>per hour</small></div>
      <dl class="dl"><dt>Category</dt><dd>${esc(v.category)}</dd><dt>Hourly rate</dt><dd>${rm(v.hourly_rate)}</dd><dt>Availability</dt><dd>${on ? 'Open for booking' : 'Currently not bookable'}</dd><dt>Listed</dt><dd>${fmtDate(v.created_at)}</dd></dl>
      <p class="field-hint mt">The system stores a booking date and number of hours — it does not hold time slots, so exact start times are agreed with staff.</p></div>
    <div id="side">${canBook ? (on ? `<form class="card card-pad" id="bk" novalidate><h3 style="margin-bottom:16px">Reserve this venue</h3>
        <div class="field"><label for="d">Date</label><input class="input" id="d" type="date" min="${todayISO()}" required><div class="field-error" data-err="d"></div><div class="field-hint" id="busy"></div></div>
        <div class="field"><label for="h">Hours</label><input class="input" id="h" type="number" min="1" max="12" value="1" required><div class="field-error" data-err="h"></div></div>
        <div class="sum-row"><span>${rm(v.hourly_rate)} × <span id="hn">1</span> h</span></div><div class="sum-row total"><span>Total</span><span id="tot">${rm(v.hourly_rate)}</span></div>
        <button class="btn btn-block mt" type="submit">Request booking</button></form>` : `<div class="card card-pad"><div class="notice warn">${icon('alert')}<div>This venue is currently unavailable, so the server will not accept new bookings for it.</div></div><a class="btn btn-ghost" href="#/venues">Browse other venues</a></div>`)
      : `<div class="card card-pad"><div class="notice">${icon('info')}<div>Bookings are made from customer accounts. You are signed in as <b>${esc(user.role)}</b>.</div></div>${user.role === 'staff' || user.role === 'admin' ? '<a class="btn btn-ghost" href="#/manage/venues">Manage venues</a>' : ''}</div>`}</div></div>`;
  const form = $('#bk', el); if (!form) return;
  const upd = () => { const h = Math.max(0, parseInt($('#h', el).value, 10) || 0); $('#hn', el).textContent = h; $('#tot', el).textContent = rm(v.hourly_rate * h); };
  const busy = () => {
    const d = $('#d', el).value; if (!d) { $('#busy', el).textContent = ''; return; }
    const n = bookings.filter(b => b.booking_type === 'venue' && Number(b.venue_id) === Number(v.id) && b.booking_date === d && b.status !== 'cancelled').length;
    $('#busy', el).textContent = n ? `${n} existing booking${n > 1 ? 's' : ''} on this date — staff will confirm times.` : 'No other bookings recorded for this date.';
  };
  form.addEventListener('input', e => { if (e.target.id === 'h') upd(); if (e.target.id === 'd') busy(); });
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const d = $('#d', el).value, h = parseInt($('#h', el).value, 10);
    $('[data-err=d]', el).textContent = ''; $('[data-err=h]', el).textContent = '';
    let ok = true;
    if (!d || parseDate(d) < parseDate(todayISO())) { $('[data-err=d]', el).textContent = 'Choose today or a future date.'; ok = false; }
    if (!(h >= 1 && h <= 12)) { $('[data-err=h]', el).textContent = 'Enter between 1 and 12 hours.'; ok = false; }
    if (!ok) return;
    await withBusy($('button[type=submit]', el), async () => {
      try {
        const r = await api.createBooking({ customer_id: Number(user.id), booking_type: 'venue', venue_id: Number(v.id), booking_date: d, quantity: h });
        toast('Booking created', 'success');
        bookingSuccess($('#side', el), { ...r, total: v.hourly_rate * h, type: 'venue', name: v.venue_name, qty: h }, user, 'venue booking');
      } catch (err) { toast(err.message, 'error'); }
    });
  });
}

/* ================= EVENTS ================= */
function eventCard(e) {
  const rem = remaining(e), pct = Math.min(100, Math.round((Number(e.tickets_sold) / Number(e.total_tickets)) * 100)), s = eventState(e);
  return `<article class="card vcard"><div class="vmedia">${sportArt(guessSport(e.event_name))}${badge(s, s)}</div>
    <div class="vbody"><div class="vkind">${fmtDate(e.event_date)}</div><h3>${esc(e.event_name)}</h3><div class="vmeta"><span>${icon('ticket', 'i-sm')} ${num(rem)} left</span><span>${Number(e.ticket_price) === 0 ? 'Free entry' : rm(e.ticket_price) + ' per ticket'}</span></div>
    <div><div class="progress ${rem === 0 ? 'full' : ''}"><i style="width:${pct}%"></i></div><div class="cell-sub" style="margin-top:6px">${num(e.tickets_sold)} of ${num(e.total_tickets)} tickets taken</div></div>
    <div class="vfoot"><div class="vbtns"><a class="btn btn-ghost" href="#/events/${e.id}">${icon('eye', 'i-sm')} View</a>${s === 'open' ? `<a class="btn btn-soft" href="#/events/${e.id}">Get tickets</a>` : `<span class="btn btn-ghost" aria-disabled="true" style="opacity:.55;pointer-events:none">${s === 'past' ? 'Ended' : 'Sold out'}</span>`}</div></div></div></article>`;
}

export async function eventsPage(ctx) {
  const { el, user } = ctx;
  const head = banner('Events', 'Tournaments and community sessions you can join.', ['organiser', 'admin'].includes(user.role) ? '<a class="btn" href="#/manage/events">Manage events</a>' : '');
  el.innerHTML = head + `<div class="section">${skelCards(6)}</div>`;
  let events;
  try { events = await api.events(); } catch (err) { if (ctx.alive()) el.innerHTML = pageHead('Events') + `<div class="card">${errorState(err.message)}</div>`; return; }
  if (!ctx.alive()) return;
  const st = { q: '', when: 'upcoming', price: '', sort: 'date' };
  el.innerHTML = head + `
    <div class="finder"><div class="finder-in">
      <div class="finder-cell"><label for="q">Event</label><input class="input" id="q" type="search" placeholder="Search by event name" autocomplete="off"></div>
      <div class="finder-cell"><label for="price">Price</label><select class="select" id="price"><option value="">Any price</option><option value="free">Free</option><option value="paid">Paid</option></select></div>
      <div class="finder-cell"><label for="sort">Sort by</label><select class="select" id="sort"><option value="date">Date</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option></select></div>
    </div></div>
    <div class="section"><div class="tabs-line" id="when" role="tablist"><button class="tab-line on" data-when="upcoming">Upcoming</button><button class="tab-line" data-when="past">Past</button><button class="tab-line" data-when="all">All events</button></div>
      <div class="section-head"><h2 id="ttl">Upcoming events</h2><span class="count" id="count" aria-live="polite"></span></div><div id="grid"></div></div>`;
  const TITLES = { upcoming: 'Upcoming events', past: 'Past events', all: 'All events' };
  const draw = () => {
    let r = events.filter(e => (!st.q || e.event_name.toLowerCase().includes(st.q)) && (st.when === 'all' || (st.when === 'upcoming') === isUpcoming(e.event_date)) && (!st.price || (st.price === 'free') === (Number(e.ticket_price) === 0)));
    r.sort((a, b) => st.sort === 'low' ? a.ticket_price - b.ticket_price : st.sort === 'high' ? b.ticket_price - a.ticket_price : (st.when === 'past' ? b.event_date.localeCompare(a.event_date) : a.event_date.localeCompare(b.event_date)));
    $('#ttl', el).textContent = TITLES[st.when];
    $('#count', el).textContent = `${r.length} event${r.length === 1 ? '' : 's'}`;
    $('#grid', el).innerHTML = r.length ? `<div class="grid grid-cards">${r.map(eventCard).join('')}</div>` : `<div class="card">${emptyState(events.length ? 'No events match' : 'No events yet', events.length ? 'Try the "All events" tab or clear the filters.' : 'Organisers have not published any events yet.')}</div>`;
  };
  el.addEventListener('input', e => { if (e.target.id === 'q') { st.q = e.target.value.trim().toLowerCase(); draw(); } });
  el.addEventListener('change', e => { if (e.target.id === 'price') { st.price = e.target.value; draw(); } if (e.target.id === 'sort') { st.sort = e.target.value; draw(); } });
  el.addEventListener('click', e => { const c = e.target.closest('[data-when]'); if (c) { st.when = c.dataset.when; $$('#when .tab-line', el).forEach(x => x.classList.toggle('on', x === c)); draw(); } });
  draw();
}

export async function eventDetail(ctx) {
  const { el, user, params } = ctx;
  el.innerHTML = skelCards(1);
  let e;
  try { e = await api.event(params[0]); } catch (err) { if (ctx.alive()) el.innerHTML = `<div class="card">${errorState(err.message, err.status !== 404)}</div>`; return; }
  if (!ctx.alive()) return;
  ctx.setTitle(e.event_name);
  const s = eventState(e), rem = remaining(e), canBook = user.role === 'customer', price = Number(e.ticket_price);
  const pct = Math.min(100, Math.round((Number(e.tickets_sold) / Number(e.total_tickets)) * 100));
  const maxQ = Math.min(rem, 10);
  el.innerHTML = `<div class="detail-hero">${sportArt(guessSport(e.event_name))}</div>
    <div class="split"><div class="card card-pad"><div style="display:flex;gap:10px;margin-bottom:10px">${badge(s, s)}</div><h1 style="font-size:28px">${esc(e.event_name)}</h1>
      <div class="price" style="margin:12px 0 18px">${price === 0 ? 'Free entry' : rm(price) + ' <small>per ticket</small>'}</div>
      <dl class="dl"><dt>Date</dt><dd>${fmtDate(e.event_date)}</dd><dt>Ticket price</dt><dd>${price === 0 ? 'Free' : rm(price)}</dd><dt>Capacity</dt><dd>${num(e.total_tickets)} tickets</dd><dt>Sold</dt><dd>${num(e.tickets_sold)} (excludes cancelled bookings)</dd><dt>Remaining</dt><dd>${num(rem)}</dd></dl>
      <div class="progress mt ${rem === 0 ? 'full' : ''}"><i style="width:${pct}%"></i></div></div>
    <div id="side">${canBook ? (s === 'open' ? `<form class="card card-pad" id="bk" novalidate><h3 style="margin-bottom:16px">Get tickets</h3>
        <div class="field"><label for="q">Tickets</label><input class="input" id="q" type="number" min="1" max="${maxQ}" value="1" required><div class="field-error" data-err="q"></div><div class="field-hint">Up to ${maxQ} per booking.</div></div>
        <div class="sum-row"><span>Event date</span><span>${fmtDate(e.event_date)}</span></div><div class="sum-row"><span>${price === 0 ? 'Free' : rm(price)} × <span id="qn">1</span></span></div><div class="sum-row total"><span>Total</span><span id="tot">${rm(price)}</span></div>
        <button class="btn btn-block mt" type="submit">Book tickets</button></form>`
        : `<div class="card card-pad"><div class="notice warn">${icon('alert')}<div>${s === 'past' ? 'This event has already taken place.' : 'This event is sold out.'}</div></div><a class="btn btn-ghost" href="#/events">Browse other events</a></div>`)
      : `<div class="card card-pad"><div class="notice">${icon('info')}<div>Tickets are booked from customer accounts. You are signed in as <b>${esc(user.role)}</b>.</div></div>${['organiser', 'admin'].includes(user.role) ? '<a class="btn btn-ghost" href="#/manage/events">Manage events</a>' : ''}</div>`}</div></div>`;
  const form = $('#bk', el); if (!form) return;
  form.addEventListener('input', () => { const q = Math.max(0, parseInt($('#q', el).value, 10) || 0); $('#qn', el).textContent = q; $('#tot', el).textContent = rm(price * q); });
  form.addEventListener('submit', async ev => {
    ev.preventDefault();
    const q = parseInt($('#q', el).value, 10); $('[data-err=q]', el).textContent = '';
    if (!(q >= 1 && q <= maxQ)) { $('[data-err=q]', el).textContent = `Enter between 1 and ${maxQ} tickets.`; return; }
    await withBusy($('button[type=submit]', el), async () => {
      try {
        const r = await api.createBooking({ customer_id: Number(user.id), booking_type: 'event', event_id: Number(e.id), booking_date: e.event_date, quantity: q });
        toast('Tickets booked', 'success');
        bookingSuccess($('#side', el), { ...r, total: price * q, type: 'event', name: e.event_name, qty: q }, user, 'ticket booking');
      } catch (err) { toast(err.message, 'error'); }
    });
  });
}
