import { icon, LOGO } from '../core/icons.js';
import { esc, $, withBusy, toast, LINES } from '../core/ui.js';
import { api, login } from '../core/api.js';

function top(here) {
  return `<header class="auth-top"><div class="auth-top-in"><a class="brand" href="#/login"><span class="brand-mark">${LOGO}</span><span>SportSphere</span></a>
    <div class="links">${here === 'login' ? '<a href="#/register">Sign up</a>' : '<a href="#/login">Sign in</a>'}</div></div></header>`;
}
function art() {
  return `<aside class="auth-art">${LINES}
    <div><h2>Book the court. Run the event.</h2><p>One place to reserve venues, join events and keep every booking in order.</p></div>
    <div class="auth-points">
      <div>${icon('court')} Reserve futsal, badminton and pickleball courts</div>
      <div>${icon('ticket')} Buy event tickets and get a QR entry code</div>
      <div>${icon('chart')} Role-based tools for organisers, staff and admins</div>
    </div></aside>`;
}
const shell = (here, card) => `<div class="auth">${top(here)}<main class="auth-main" id="main"><div class="auth-panel">${art()}<div class="auth-form-side"><div class="auth-card">${card}</div></div></div></main></div>`;
const passField = (id, label, auto) => `<div class="field"><label for="${id}">${label}</label><div class="input-wrap"><input class="input" id="${id}" type="password" autocomplete="${auto}" required><button type="button" class="toggle" data-toggle="${id}" aria-label="Show password">${icon('eye')}</button></div><div class="field-error" data-err="${id}"></div></div>`;

function bindToggle(root) {
  root.addEventListener('click', e => {
    const t = e.target.closest('[data-toggle]'); if (!t) return;
    const inp = $('#' + t.dataset.toggle, root); const show = inp.type === 'password';
    inp.type = show ? 'text' : 'password';
    t.innerHTML = icon(show ? 'eyeoff' : 'eye'); t.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
  });
}
function setErr(root, id, msg) { const e = $(`[data-err="${id}"]`, root); if (e) e.textContent = msg || ''; const i = $('#' + id, root); if (i) i.classList.toggle('is-invalid', !!msg); }
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function renderLogin(root, onAuthed, notice = '') {
  root.innerHTML = shell('login', `
    <h1>Welcome back</h1><p class="lead">Sign in to manage your bookings and events.</p>
    <div id="form-error" class="form-error" role="alert" hidden></div>
    ${notice ? `<div class="notice warn">${icon('info')}<div>${esc(notice)}</div></div>` : ''}
    <form id="login" novalidate>
      <div class="field"><label for="email">Email</label><input class="input" id="email" type="email" autocomplete="username" placeholder="you@example.com" required><div class="field-error" data-err="email"></div></div>
      ${passField('password', 'Password', 'current-password')}
      <button class="btn btn-block" type="submit">Sign in</button>
    </form>
    <p class="auth-alt">New to SportSphere? <a href="#/register">Create an account</a></p>`);
  bindToggle(root);
  const form = $('#login', root), box = $('#form-error', root);
  form.addEventListener('submit', async e => {
    e.preventDefault(); box.hidden = true;
    const email = $('#email', root).value.trim(), pw = $('#password', root).value;
    let ok = true;
    setErr(root, 'email', ''); setErr(root, 'password', '');
    if (!EMAIL.test(email)) { setErr(root, 'email', 'Enter a valid email address.'); ok = false; }
    if (!pw.trim()) { setErr(root, 'password', 'Enter your password.'); ok = false; }
    if (!ok) return;
    await withBusy($('button[type=submit]', root), async () => {
      try { const user = await login(email, pw); onAuthed(user); }
      catch (err) { box.innerHTML = `${icon('alert')}<div>${esc(err.message)}</div>`; box.hidden = false; }
    });
  });
  $('#email', root).focus();
}

export function renderRegister(root, onAuthed) {
  root.innerHTML = shell('register', `
    <h1>Create your account</h1><p class="lead">Customer accounts can book venues and buy event tickets.</p>
    <div id="form-error" class="form-error" role="alert" hidden></div>
    <form id="reg" novalidate>
      <div class="field"><label for="name">Full name</label><input class="input" id="name" autocomplete="name" required><div class="field-error" data-err="name"></div></div>
      <div class="field"><label for="email">Email</label><input class="input" id="email" type="email" autocomplete="email" required><div class="field-error" data-err="email"></div></div>
      ${passField('password', 'Password', 'new-password')}
      ${passField('confirm', 'Confirm password', 'new-password')}
      <button class="btn btn-block" type="submit">Create account</button>
    </form>
    <p class="auth-alt">Already registered? <a href="#/login">Sign in</a></p>`);
  bindToggle(root);
  const box = $('#form-error', root);
  $('#reg', root).addEventListener('submit', async e => {
    e.preventDefault(); box.hidden = true;
    const name = $('#name', root).value.trim(), email = $('#email', root).value.trim(), pw = $('#password', root).value, cf = $('#confirm', root).value;
    ['name', 'email', 'password', 'confirm'].forEach(k => setErr(root, k, ''));
    let ok = true;
    if (name.length < 2) { setErr(root, 'name', 'Enter your full name.'); ok = false; }
    if (!EMAIL.test(email)) { setErr(root, 'email', 'Enter a valid email address.'); ok = false; }
    if (pw.length < 6) { setErr(root, 'password', 'Use at least 6 characters.'); ok = false; }
    if (cf !== pw) { setErr(root, 'confirm', 'Passwords do not match.'); ok = false; }
    if (!ok) return;
    await withBusy($('button[type=submit]', root), async () => {
      try {
        // Role is always 'customer' — public sign-up must never request elevated access.
        await api.register({ name, email, password: pw, role: 'customer' });
        toast('Account created. Signing you in…', 'success');
        const user = await login(email, pw);
        onAuthed(user);
      } catch (err) { box.innerHTML = `${icon('alert')}<div>${esc(err.message)}</div>`; box.hidden = false; }
    });
  });
  $('#name', root).focus();
}
