import { icon } from './icons.js';

/* ---------- helpers ---------- */
export const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const rm = n => 'RM ' + (Number(n) || 0).toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
export const num = n => (Number(n) || 0).toLocaleString('en-MY');
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export function parseDate(s) { // 'YYYY-MM-DD' or 'YYYY-MM-DD HH:MM:SS' -> local Date
  if (!s) return null;
  const [y, mo, d] = String(s).slice(0, 10).split('-').map(Number);
  return new Date(y, mo - 1, d);
}
export const fmtDate = s => { const d = parseDate(s); return d ? `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}` : '—'; };
export const today = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), d.getDate()); };
export const todayISO = () => { const d = today(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
export const isUpcoming = s => { const d = parseDate(s); return d && d >= today(); };
export const initials = n => String(n || '?').split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
export const cap = s => String(s || '').charAt(0).toUpperCase() + String(s || '').slice(1);
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/* ---------- badges ---------- */
const BADGE = {
  confirmed: 'ok', completed: 'ok', available: 'ok', pending: 'warn', cancelled: 'bad', failed: 'bad', unavailable: 'bad',
  venue: 'info plain', event: 'info plain', admin: 'info plain', staff: 'info plain', organiser: 'info plain', customer: 'plain',
  'sold out': 'warn', open: 'ok', past: 'plain',
};
export const badge = (label, kind) => `<span class="badge ${BADGE[kind || String(label).toLowerCase()] || ''}">${esc(cap(label))}</span>`;

/* ---------- state blocks ---------- */
export const emptyState = (title, text, action = '') => `<div class="empty"><div class="ico">${icon('grid', 'i-lg')}</div><h4>${esc(title)}</h4><p>${esc(text)}</p>${action}</div>`;
export const errorState = (msg, retry = true) => `<div class="errstate"><div class="ico">${icon('alert', 'i-lg')}</div><h4>Something went wrong</h4><p>${esc(msg)}</p>${retry ? `<button class="btn btn-ghost" data-action="retry">${icon('refresh', 'i-sm')} Try again</button>` : ''}</div>`;
export const skelCards = (n = 6) => `<div class="grid grid-cards">${Array.from({ length: n }, () => '<div class="skel skel-card"></div>').join('')}</div>`;
export const skelStats = (n = 4) => `<div class="grid grid-stats">${Array.from({ length: n }, () => '<div class="skel skel-stat"></div>').join('')}</div>`;
export const skelRows = (n = 6) => Array.from({ length: n }, () => '<div class="skel skel-row"></div>').join('');

export function statCard(label, value, ico, tone = '', note = '') {
  return `<div class="card stat"><div class="stat-top"><span>${esc(label)}</span><span class="stat-ico ${tone}">${icon(ico)}</span></div><div class="stat-val">${esc(value)}</div>${note ? `<div class="stat-note">${esc(note)}</div>` : ''}</div>`;
}
export const LINES = '<svg class="lines" viewBox="0 0 1200 300" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><g fill="none" stroke="#fff" stroke-opacity=".28" stroke-width="2"><path d="M-40 280L420 40M280 300L760 30M1240 40L820 300M900 -20L1240 160"/><circle cx="1010" cy="70" r="46"/></g></svg>';
export function banner(title, sub = '', actions = '') {
  return `<section class="banner">${LINES}<div class="banner-in"><h1>${esc(title)}</h1>${sub ? `<p>${esc(sub)}</p>` : ''}${actions ? `<div class="banner-actions">${actions}</div>` : ''}</div></section>`;
}
export function pageHead(title, sub = '', actions = '') {
  return `<div class="page-head"><div><h1>${esc(title)}</h1>${sub ? `<p>${esc(sub)}</p>` : ''}</div><div class="actions">${actions}</div></div>`;
}

/* ---------- toasts ---------- */
export function toast(message, type = 'info') {
  let box = $('#toasts');
  if (!box) { box = document.createElement('div'); box.id = 'toasts'; box.className = 'toasts'; box.setAttribute('role', 'status'); box.setAttribute('aria-live', 'polite'); document.body.appendChild(box); }
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.innerHTML = `${icon(type === 'success' ? 'checkc' : type === 'error' ? 'alert' : 'info')}<div class="msg"></div><button aria-label="Dismiss">${icon('x', 'i-sm')}</button>`;
  el.querySelector('.msg').textContent = message;
  const kill = () => el.remove();
  el.querySelector('button').onclick = kill;
  box.appendChild(el);
  setTimeout(kill, type === 'error' ? 7000 : 4500);
}

/* ---------- modal ---------- */
let lastFocus = null;
export function closeModal() { const m = $('#modal-root'); if (m) { m.remove(); lastFocus && lastFocus.focus && lastFocus.focus(); } }
export function openModal({ title, body, footer = '', onMount }) {
  closeModal();
  lastFocus = document.activeElement;
  const root = document.createElement('div');
  root.id = 'modal-root';
  root.className = 'modal-back';
  root.innerHTML = `<div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-head"><h3 id="modal-title">${esc(title)}</h3><button class="icon-btn" data-close aria-label="Close">${icon('x')}</button></div><div class="modal-body">${body}</div>${footer ? `<div class="modal-foot">${footer}</div>` : ''}</div>`;
  root.addEventListener('mousedown', e => { if (e.target === root) closeModal(); });
  root.addEventListener('click', e => { if (e.target.closest('[data-close]')) closeModal(); });
  root.addEventListener('keydown', e => {
    if (e.key === 'Escape') closeModal();
    if (e.key === 'Tab') { // simple focus trap
      const f = $$('button:not([disabled]),input,select,textarea,a[href]', root).filter(x => x.offsetParent !== null);
      if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  document.body.appendChild(root);
  const focusTarget = $('input:not([type=hidden]),select,textarea', root) || $('[data-close]', root);
  focusTarget && focusTarget.focus();
  onMount && onMount(root);
  return root;
}
export function confirmDialog({ title, message, confirmLabel = 'Confirm', danger = false }) {
  return new Promise(resolve => {
    let done = false;
    const finish = v => { if (!done) { done = true; resolve(v); } };
    const root = openModal({
      title, body: `<p class="muted">${esc(message)}</p>`,
      footer: `<button class="btn btn-ghost" data-close>Cancel</button><button class="btn ${danger ? 'btn-danger' : ''}" data-ok>${esc(confirmLabel)}</button>`,
    });
    root.querySelector('[data-ok]').onclick = () => { finish(true); closeModal(); };
    new MutationObserver((_, o) => { if (!document.body.contains(root)) { finish(false); o.disconnect(); } }).observe(document.body, { childList: true });
  });
}

/* ---------- button busy state (prevents duplicate submits) ---------- */
export async function withBusy(btn, fn) {
  if (!btn || btn.disabled) return;
  const html = btn.innerHTML;
  btn.disabled = true; btn.innerHTML = '<span class="spin"></span> Working…';
  try { return await fn(); } finally { if (document.body.contains(btn)) { btn.disabled = false; btn.innerHTML = html; } }
}

/* ---------- generated sport artwork (local inline SVG, not data) ---------- */
const ART = {
  futsal: l => `<rect x="20" y="20" width="280" height="140" rx="6" ${l}/><path d="M160 20v140" ${l}/><circle cx="160" cy="90" r="24" ${l}/><rect x="20" y="58" width="34" height="64" ${l}/><rect x="266" y="58" width="34" height="64" ${l}/>`,
  badminton: l => `<rect x="60" y="16" width="200" height="148" ${l}/><path d="M60 90h200M110 16v148M210 16v148M60 40h200M60 140h200" ${l}/><path d="M160 16v24M160 140v24" ${l}/>`,
  pickleball: l => `<rect x="50" y="22" width="220" height="136" ${l}/><path d="M160 22v136M50 62h220M50 118h220" ${l}/><path d="M104 62v56M216 62v56" ${l}/>`,
  other: l => `<rect x="20" y="20" width="280" height="140" rx="6" ${l}/><circle cx="160" cy="90" r="34" ${l}/><path d="M160 20v140" ${l}/>`,
};
export function sportArt(category = '') {
  const c = String(category).toLowerCase();
  const key = ART[c] ? c : 'other';
  const pal = { futsal: ['#1139bd', '#3b6bff'], badminton: ['#0b6e8a', '#22a6c4'], pickleball: ['#2a3fc9', '#6a86ff'], other: ['#24449e', '#4f78e0'] }[key];
  const id = 'g' + key;
  return `<svg viewBox="0 0 320 180" preserveAspectRatio="xMidYMid slice" role="img" aria-label="${esc(category || 'Sport')} court illustration"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${pal[0]}"/><stop offset="1" stop-color="${pal[1]}"/></linearGradient></defs><rect width="320" height="180" fill="url(#${id})"/>${ART[key]('fill="none" stroke="rgba(255,255,255,.7)" stroke-width="2"')}<circle cx="268" cy="38" r="6" fill="#ffd447"/></svg>`;
}

/* ---------- charts (SVG/CSS, drawn from real data passed in) ---------- */
export function donut(parts) { // [{label, value, color}]
  const total = parts.reduce((a, p) => a + p.value, 0);
  const r = 52, C = 2 * Math.PI * r;
  let off = 0;
  const segs = total ? parts.filter(p => p.value > 0).map(p => {
    const len = (p.value / total) * C;
    const s = `<circle cx="70" cy="70" r="${r}" fill="none" stroke="${p.color}" stroke-width="16" stroke-dasharray="${len} ${C - len}" stroke-dashoffset="${-off}" transform="rotate(-90 70 70)"/>`;
    off += len; return s;
  }).join('') : `<circle cx="70" cy="70" r="${r}" fill="none" stroke="#e8ecf5" stroke-width="16"/>`;
  return `<div class="donut-wrap"><svg class="donut" viewBox="0 0 140 140" role="img" aria-label="Distribution chart">${segs}<text class="total" x="70" y="68" text-anchor="middle" font-size="24" font-weight="800">${total}</text><text class="cap" x="70" y="87" text-anchor="middle" font-size="11">total</text></svg><div class="legend">${parts.map(p => `<div><i style="background:${p.color}"></i>${esc(p.label)}<b>${p.value}</b></div>`).join('')}</div></div>`;
}
export function bars(rows, fmt = num) { // [{label, value, tone}]
  const max = Math.max(1, ...rows.map(r => r.value));
  return `<div class="bars">${rows.map(r => `<div class="bar-row"><span class="lbl" title="${esc(r.label)}">${esc(r.label)}</span><div class="bar-track"><i class="${r.tone || ''}" style="width:${Math.max(2, (r.value / max) * 100)}%"></i></div><span class="val">${esc(fmt(r.value))}</span></div>`).join('')}</div>`;
}

/* ---------- data table with search, filter, sort, pagination ---------- */
export function mountTable(host, { columns, rows, searchText, filters = [], pageSize = 10, emptyTitle = 'No records', emptyText = 'Nothing to show yet.', searchPlaceholder = 'Search…' }) {
  const st = { q: '', page: 1, sort: null, dir: 1, f: {} };
  host.innerHTML = `<div class="toolbar">${searchText ? `<div class="search">${icon('search', 'i-sm')}<input class="input" type="search" placeholder="${esc(searchPlaceholder)}" aria-label="${esc(searchPlaceholder)}"></div>` : ''}${filters.map((f, i) => `<select class="select" data-f="${i}" aria-label="${esc(f.label)}"><option value="">${esc(f.label)}: All</option>${f.options.map(o => `<option value="${esc(o)}">${esc(cap(o))}</option>`).join('')}</select>`).join('')}</div><div class="table-wrap"></div><div class="pager"></div>`;
  const wrap = $('.table-wrap', host), pager = $('.pager', host);
  function view() {
    let r = rows.filter(row => (!st.q || searchText(row).toLowerCase().includes(st.q)) && filters.every((f, i) => !st.f[i] || String(f.get(row)) === st.f[i]));
    if (st.sort != null) { const c = columns[st.sort]; r = [...r].sort((a, b) => { const x = c.sort(a), y = c.sort(b); return (x > y ? 1 : x < y ? -1 : 0) * st.dir; }); }
    const pages = Math.max(1, Math.ceil(r.length / pageSize));
    st.page = Math.min(st.page, pages);
    const slice = r.slice((st.page - 1) * pageSize, st.page * pageSize);
    if (!r.length) { wrap.innerHTML = emptyState(rows.length ? 'No matches' : emptyTitle, rows.length ? 'Try a different search or filter.' : emptyText); pager.innerHTML = ''; return; }
    wrap.innerHTML = `<table class="tbl"><thead><tr>${columns.map((c, i) => `<th class="${c.sort ? 'sortable' : ''} ${c.cls || ''}" ${c.sort ? `data-sort="${i}" tabindex="0" aria-sort="${st.sort === i ? (st.dir > 0 ? 'ascending' : 'descending') : 'none'}"` : ''}>${esc(c.label)}${st.sort === i ? (st.dir > 0 ? ' ↑' : ' ↓') : ''}</th>`).join('')}</tr></thead><tbody>${slice.map(row => `<tr>${columns.map(c => `<td class="${c.cls || ''}">${c.render(row)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
    const from = (st.page - 1) * pageSize + 1;
    pager.innerHTML = `<span>Showing ${from}–${from + slice.length - 1} of ${r.length}</span><div class="btns"><button class="btn btn-ghost btn-sm" data-pg="-1" ${st.page <= 1 ? 'disabled' : ''}>${icon('chevl', 'i-sm')} Prev</button><span style="align-self:center">Page ${st.page} / ${pages}</span><button class="btn btn-ghost btn-sm" data-pg="1" ${st.page >= pages ? 'disabled' : ''}>Next ${icon('chevr', 'i-sm')}</button></div>`;
  }
  host.addEventListener('input', e => { if (e.target.matches('input[type=search]')) { st.q = e.target.value.trim().toLowerCase(); st.page = 1; view(); } });
  host.addEventListener('change', e => { if (e.target.matches('select[data-f]')) { st.f[e.target.dataset.f] = e.target.value; st.page = 1; view(); } });
  const sortBy = th => { const i = +th.dataset.sort; if (st.sort === i) st.dir *= -1; else { st.sort = i; st.dir = 1; } view(); };
  host.addEventListener('click', e => {
    const th = e.target.closest('th[data-sort]'); if (th) return sortBy(th);
    const pg = e.target.closest('[data-pg]'); if (pg) { st.page += +pg.dataset.pg; view(); }
  });
  host.addEventListener('keydown', e => { const th = e.target.closest('th[data-sort]'); if (th && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); sortBy(th); } });
  view();
  return { setRows(r) { rows = r; view(); } };
}
