// Venue photos.
//
// The backend's venues table has no image column (id, venue_name, category, hourly_rate, is_available, created_at)
// and this project may not change the backend, so photos live in the frontend: assets/venues/*.jpg, listed below
// and matched to venues BY NAME. Every screen that shows a venue gets its picture from the helpers in this file,
// so a photo is added, fixed or removed in exactly one place.
//
//  - Matching is by venue name only (case and extra spaces ignored). There is no match by sport/category, so a
//    futsal photo is never shown for a different futsal court.
//  - A venue with no entry here, or whose file fails to load, shows the generated court illustration (sportArt)
//    that the app used before photos existed.
//  - A venue may list several images; the detail page then shows a small gallery and cards show a "N photos" chip.
//
// To add a photo: copy the file into assets/venues/ and add a line to the list below using the venue's exact name.
import { esc, sportArt } from './ui.js';

const DIR = 'assets/venues/'; // relative to index.html

const key = n => String(n ?? '').toLowerCase().replace(/\s+/g, ' ').trim();

/* One entry per venue name. Each image: file, w/h of that file, optional `small` (+ `sw` its width) for phones and
   thumbnails, optional `focus` (CSS object-position) so the important part of the picture survives cropping. */
export const VENUE_PHOTOS = Object.create(null);
const add = (name, ...images) => { VENUE_PHOTOS[key(name)] = images; };

add('Indoor Futsal Court A', { file: 'indoor-futsal-court-a.jpg', w: 600, h: 450, focus: '50% 55%' });
add('Indoor Futsal Court B', { file: 'indoor-futsal-court-b.jpg', w: 612, h: 408, focus: '50% 55%' });
add('Badminton Court 1', { file: 'badminton-court-1.jpg', w: 1080, h: 1080, small: 'badminton-court-1-800.jpg', sw: 800, focus: '50% 55%' });
add('Badminton Court 2', { file: 'badminton-court-2.jpg', w: 1183, h: 887, small: 'badminton-court-2-800.jpg', sw: 800, focus: '50% 55%' });
add('Pickleball Hub Court', { file: 'pickleball-hub-court.jpg', w: 1400, h: 933, small: 'pickleball-hub-court-800.jpg', sw: 800, focus: '50% 55%' });

/* ---------- lookup ---------- */
const nameOf = v => (v && typeof v === 'object') ? (v.venue_name ?? v.name) : v;
export const photosFor = v => VENUE_PHOTOS[key(nameOf(v))] || [];

/** Best guess at a sport from a name; used only to pick the fallback illustration when no category is known. */
export const sportOf = (name = '') => { const n = String(name || '').toLowerCase(); return n.includes('futsal') ? 'futsal' : n.includes('badminton') ? 'badminton' : n.includes('pickleball') ? 'pickleball' : 'other'; };
const categoryOf = (v, fallbackName) => (v && typeof v === 'object' && v.category) ? v.category : sportOf(fallbackName);

/* ---------- markup ---------- */
function imgTag(p, { alt, cat, sizes, thumb = false, eager = false }) {
  const url = f => esc(DIR + f);
  const src = thumb ? (p.small || p.file) : p.file;
  const srcset = !thumb && p.small ? ` srcset="${url(p.small)} ${p.sw}w, ${url(p.file)} ${p.w}w" sizes="${esc(sizes || '100vw')}"` : '';
  const dims = thumb && p.small ? `width="${p.sw}" height="${Math.round(p.sw * p.h / p.w)}"` : `width="${p.w}" height="${p.h}"`;
  return `<img class="vphoto" src="${url(src)}"${srcset} ${dims} alt="${esc(alt)}" data-cat="${esc(cat)}" style="--focus:${esc(p.focus || '50% 50%')}" decoding="async" ${eager ? '' : 'loading="lazy"'}>`;
}
const photoAlt = (p, name) => p.alt || `Photo of ${name}`;

/** Inside a .vmedia box (cards): the venue's first photo, or the illustration when there is none. */
export function venueMedia(v, { sizes = '(max-width: 640px) 100vw, (max-width: 1100px) 50vw, 400px' } = {}) {
  const name = nameOf(v), cat = categoryOf(v, name), photos = photosFor(v);
  if (!photos.length) return sportArt(cat);
  const chip = photos.length > 1 ? `<span class="photo-count">${photos.length} photos</span>` : '';
  return imgTag(photos[0], { alt: photoAlt(photos[0], name), cat, sizes }) + chip;
}

/** A small square-ish picture for tables and lists. Decorative: the venue name is always printed next to it. */
export function venueThumb(v, cls = '') {
  const name = nameOf(v), cat = categoryOf(v, name), p = photosFor(v)[0];
  return `<span class="thumb ${cls}" aria-hidden="true">${p ? imgTag(p, { alt: '', cat, thumb: true }) : sportArt(cat)}</span>`;
}

/** Thumbnail for a booking row: the venue photo for venue bookings, the event illustration for event tickets. */
export function bookingThumb(b, cls = '') {
  if (b.booking_type === 'event') return `<span class="thumb ${cls}" aria-hidden="true">${sportArt(sportOf(b.event_name))}</span>`;
  return venueThumb(b.venue_name || '', cls); // a deleted venue has no name, so it gets the neutral illustration
}

/** Wide picture at the top of a booking modal (venue bookings only). */
export function bookingBanner(b) {
  if (b.booking_type === 'event') return '';
  const name = b.venue_name || '', cat = sportOf(name), p = photosFor(name)[0];
  return `<div class="modal-media">${p ? imgTag(p, { alt: photoAlt(p, name), cat, sizes: '(max-width: 560px) 100vw, 540px' }) : sportArt(cat)}</div>`;
}

/** Table cell: picture, then the two text lines. `main` and `sub` are already-escaped HTML. */
export const mediaCell = (thumb, main, sub = '') => `<div class="cell-venue">${thumb}<div><div class="cell-main">${main}</div>${sub ? `<div class="cell-sub">${sub}</div>` : ''}</div></div>`;

/** Detail-page picture area: the photo, plus a thumbnail strip when the venue has more than one. */
export function venueGallery(v) {
  const name = nameOf(v), cat = categoryOf(v, name), photos = photosFor(v);
  const sizes = '(max-width: 1080px) 100vw, 660px';
  if (!photos.length) return `<div class="gallery"><div class="gal-main">${sportArt(cat)}</div></div>`;
  const main = imgTag(photos[0], { alt: photoAlt(photos[0], name), cat, sizes, eager: true });
  if (photos.length === 1) return `<div class="gallery"><div class="gal-main">${main}</div></div>`;
  const strip = photos.map((p, i) => {
    const small = p.small || p.file;
    return `<button type="button" class="gal-thumb${i ? '' : ' on'}" data-gal-i="${i}" aria-pressed="${i ? 'false' : 'true'}" aria-label="Show photo ${i + 1} of ${photos.length}"
      data-file="${esc(DIR + p.file)}" data-srcset="${p.small ? esc(`${DIR + p.small} ${p.sw}w, ${DIR + p.file} ${p.w}w`) : ''}" data-w="${p.w}" data-h="${p.h}" data-focus="${esc(p.focus || '50% 50%')}" data-alt="${esc(photoAlt(p, name))}"><img class="vphoto" src="${esc(DIR + small)}" alt="" loading="lazy" decoding="async" data-cat="${esc(cat)}" style="--focus:${esc(p.focus || '50% 50%')}"></button>`;
  }).join('');
  return `<div class="gallery" data-gallery data-cat="${esc(cat)}"><div class="gal-main">${main}<span class="photo-count" data-gal-count>1 / ${photos.length}</span></div><div class="gal-strip" role="group" aria-label="Photos of ${esc(name)}">${strip}</div></div>`;
}

/* ---------- behaviour: gallery switching and broken-image fallback (installed once from app.js) ---------- */
function showInGallery(btn) {
  const g = btn.closest('[data-gallery]'), main = g && g.querySelector('.gal-main img');
  if (!main) return;
  g.querySelectorAll('.gal-thumb').forEach(b => { const on = b === btn; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); });
  const d = btn.dataset;
  main.alt = d.alt; main.width = +d.w; main.height = +d.h; main.style.setProperty('--focus', d.focus);
  if (d.srcset) main.setAttribute('srcset', d.srcset); else main.removeAttribute('srcset');
  main.src = d.file;
  refreshCount(g);
}

// "2 / 3" counts only the photos that are usable; a photo whose file failed to load is dropped from the total.
function refreshCount(g) {
  const c = g.querySelector('[data-gal-count]'); if (!c) return;
  const live = [...g.querySelectorAll('.gal-thumb')].filter(b => !b.dataset.failed);
  c.textContent = `${Math.max(0, live.findIndex(b => b.classList.contains('on'))) + 1} / ${live.length}`;
}

function replaceWithArt(img) {
  const holder = img.parentElement;
  img.insertAdjacentHTML('afterend', sportArt(img.dataset.cat || 'other'));
  img.remove();
  if (holder) holder.querySelectorAll('.photo-count').forEach(n => n.remove());
}

function onImageError(e) {
  const img = e.target;
  if (!(img instanceof HTMLImageElement) || !img.classList.contains('vphoto')) return;
  const g = img.closest('[data-gallery]');
  if (g) { // several photos: drop the one that failed and show another if any are left
    const thumbs = [...g.querySelectorAll('.gal-thumb')];
    if (img.closest('.gal-thumb')) {
      const btn = img.closest('.gal-thumb'); btn.dataset.failed = '1';
      if (btn.classList.contains('on')) { const next = thumbs.find(b => !b.dataset.failed); if (next) showInGallery(next); }
      btn.hidden = true;
    } else {
      const next = thumbs.find(b => !b.dataset.failed && b.dataset.file !== img.getAttribute('src'));
      const cur = thumbs.find(b => b.dataset.file === img.getAttribute('src') || b.classList.contains('on'));
      if (cur) { cur.dataset.failed = '1'; cur.hidden = true; }
      if (next) showInGallery(next); else replaceWithArt(img);
    }
    refreshCount(g);
    if (thumbs.filter(b => !b.dataset.failed).length < 2) { const s = g.querySelector('.gal-strip'); if (s) s.hidden = true; const c = g.querySelector('[data-gal-count]'); if (c) c.hidden = true; }
    return;
  }
  replaceWithArt(img);
}

let installed = false;
export function installVenuePhotoBehaviour() {
  if (installed) return; installed = true;
  document.addEventListener('error', onImageError, true); // error does not bubble, so listen in the capture phase
  document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('.gal-thumb'); if (b) showInGallery(b); });
}
