import { icon, LOGO } from './core/icons.js';
import { esc, $, $$, initials, toast, errorState, skelStats } from './core/ui.js';
import { loadSession, getUser, clearSession, onUnauthorized, sessionExpiresAt, consumeExpiredOnLoad } from './core/api.js';
import { renderLogin, renderRegister } from './pages/auth.js';
import { customerDashboard, organiserDashboard, staffDashboard, adminDashboard } from './pages/dashboards.js';
import { venuesPage, venueDetail, eventsPage, eventDetail } from './pages/browse.js';
import { myBookings } from './pages/bookings.js';
import { manageBookings, manageVenues, manageEvents } from './pages/manage.js';
import { paymentsPage, usersPage } from './pages/admin.js';
import { installVenuePhotoBehaviour } from './core/venues.js';

const root = $('#root');
installVenuePhotoBehaviour(); // venue photo gallery clicks and the broken-image fallback

/* ---------- role navigation & route table ----------
   `roles` here mirrors authorizeRoles() on the server so people are not sent to pages that would answer 403.
   It is a convenience: the server still enforces access on every API call. */
const dash = {
  customer: customerDashboard, organiser: organiserDashboard, staff: staffDashboard, admin: adminDashboard,
};
const ALL = ['customer', 'organiser', 'staff', 'admin'];
const ROUTES = [
  { re: /^\/dashboard$/, roles: ALL, title: 'Dashboard', render: (c) => dash[c.user.role](c) },
  { re: /^\/venues$/, roles: ALL, title: 'Venues', render: venuesPage },
  { re: /^\/venues\/(\d+)$/, roles: ALL, title: 'Venue', parent: ['Venues', '/venues'], render: venueDetail },
  { re: /^\/events$/, roles: ALL, title: 'Events', render: eventsPage },
  { re: /^\/events\/(\d+)$/, roles: ALL, title: 'Event', parent: ['Events', '/events'], render: eventDetail },
  { re: /^\/bookings$/, roles: ['customer'], title: 'My bookings', render: myBookings },
  { re: /^\/manage\/bookings$/, roles: ['staff', 'admin'], title: 'Bookings', render: manageBookings },
  { re: /^\/manage\/venues$/, roles: ['staff', 'admin'], title: 'Manage venues', render: manageVenues },
  { re: /^\/manage\/events$/, roles: ['organiser', 'admin'], title: 'Manage events', render: manageEvents },
  { re: /^\/payments$/, roles: ['staff', 'admin'], title: 'Payments', render: paymentsPage },
  { re: /^\/users$/, roles: ['admin'], title: 'Users', render: usersPage },
];
const NAV = {
  customer: [['/dashboard', 'Dashboard', 'home'], ['/venues', 'Venues', 'court'], ['/events', 'Events', 'calendar'], ['/bookings', 'My bookings', 'ticket']],
  organiser: [['/dashboard', 'Dashboard', 'home'], ['/manage/events', 'My events', 'calendar'], ['/venues', 'Venues', 'court'], ['/events', 'All events', 'ticket']],
  staff: [['/dashboard', 'Dashboard', 'home'], ['/manage/bookings', 'Bookings', 'ticket'], ['/payments', 'Payments', 'card'], ['/manage/venues', 'Venues', 'court'], ['/events', 'Events', 'calendar']],
  admin: [['/dashboard', 'Overview', 'home'], ['/users', 'Users', 'users'], ['/manage/venues', 'Venues', 'court'], ['/manage/events', 'Events', 'calendar'], ['/manage/bookings', 'Bookings', 'ticket'], ['/payments', 'Payments', 'card']],
};
const clock = d => d ? d.toLocaleTimeString('en-MY', { hour: 'numeric', minute: '2-digit' }) : '';

/* ---------- shell ---------- */
let shellBuilt = false;
function buildShell(user) {
  const nav = NAV[user.role].map(([p, l, i]) => `<a href="#${p}" data-path="${p}">${icon(i)}<span>${esc(l)}</span></a>`).join('');
  const ends = clock(sessionExpiresAt());
  root.innerHTML = `<div class="shell">
    <header class="appbar"><div class="appbar-in">
      <a class="brand" href="#/dashboard" aria-label="SportSphere home"><span class="brand-mark">${LOGO}</span><span>SportSphere</span></a>
      <div class="spacer"></div>
      <div class="dropdown">
        <button class="who" id="user-btn" aria-haspopup="menu" aria-expanded="false" aria-label="Account menu"><span class="avatar">${esc(initials(user.name))}</span><span class="nm">${esc(user.name)}</span>${icon('chevd', 'i-sm')}</button>
        <div class="dropdown-menu" id="user-menu" role="menu" hidden><div class="dd-head"><b>${esc(user.name)}</b><span>${esc(user.role)}${ends ? ` · signed in until ${esc(ends)}` : ''}</span></div><button role="menuitem" data-action="logout">${icon('logout')} Sign out</button></div>
      </div>
    </div></header>
    <div class="tabs"><div class="tabs-in"><nav class="nav" aria-label="Primary">${nav}</nav></div></div>
    <div class="main">
      <nav class="crumbs" aria-label="Breadcrumb" id="crumbs"></nav>
      <main class="content" id="main" tabindex="-1"></main>
    </div>
    <footer class="foot">SportSphere · Sports venue and event management</footer>
  </div>`;
  shellBuilt = true;
}
function setCrumbs(list) {
  // Single-level pages need no breadcrumb: the active tab already says where you are.
  $('#crumbs').innerHTML = list.length < 2 ? '' : list.map((c, i) => i === list.length - 1 ? `<span class="here">${esc(c[0])}</span>` : `<a href="#${c[1]}">${esc(c[0])}</a><span class="sep">${icon('chevr', 'i-sm')}</span>`).join('');
}
function setActive(path) {
  $$('.nav a').forEach(a => {
    const on = path === a.dataset.path || (a.dataset.path !== '/dashboard' && path.startsWith(a.dataset.path + '/'));
    a.classList.toggle('active', on);
    if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
  const act = $('.nav a.active'); if (act && act.scrollIntoView) act.scrollIntoView({ block: 'nearest', inline: 'nearest' });
}

/* ---------- router ---------- */
let routeToken = 0;

function parse() {
  const h = location.hash.replace(/^#/, '') || '/';
  return h.split('?')[0].replace(/\/+$/, '') || '/';
}
function go(path) { if (location.hash !== '#' + path) location.hash = path; else route(); }
const afterLogin = () => { const to = route.returnTo; route.returnTo = ''; go(to && ROUTES.some(r => r.re.test(to)) ? to : '/dashboard'); };

async function route() {
  const path = parse();
  const session = loadSession(); // also drops an expired token before anything renders

  if (!session) {
    shellBuilt = false;
    if (consumeExpiredOnLoad()) route.notice = 'Your session has expired. Please sign in again.';
    if (path === '/register') return renderRegister(root, afterLogin);
    // Remember the page that was asked for so sign-in can return there.
    if (path !== '/' && path !== '/login' && !route.returnTo) route.returnTo = path;
    const note = route.notice || '';
    route.notice = '';
    document.title = 'Sign in · SportSphere';
    return renderLogin(root, afterLogin, note);
  }
  const user = getUser();
  if (path === '/login' || path === '/register' || path === '/') return go('/dashboard');
  if (!shellBuilt) buildShell(user);

  let match = null, params = [];
  for (const r of ROUTES) { const m = path.match(r.re); if (m) { match = r; params = m.slice(1); break; } }
  if (!match) { setCrumbs([['Not found', path]]); setActive(path); $('#main').innerHTML = `<div class="card">${errorState('That page does not exist.', false)}</div>`; return; }
  if (!match.roles.includes(user.role)) { toast('Your role does not have access to that page.', 'error'); return go('/dashboard'); }

  const token = ++routeToken;
  const view = document.createElement('div');
  const main = $('#main');
  main.replaceChildren(view);
  view.innerHTML = skelStats(4);
  setActive(path);
  setCrumbs(match.parent ? [match.parent, [match.title, path]] : [[match.title, path]]);
  document.title = match.title + ' · SportSphere';
  window.scrollTo(0, 0);

  const ctx = {
    el: view, user, params, path,
    alive: () => token === routeToken,
    setTitle: t => { if (token === routeToken) { setCrumbs(match.parent ? [match.parent, [t, path]] : [[t, path]]); document.title = t + ' · SportSphere'; } },
    go, reload: () => route(),
  };
  try { await match.render(ctx); }
  catch (err) { if (ctx.alive()) view.innerHTML = `<div class="card">${errorState(err.message || 'Unexpected error')}</div>`; console.error(err); }
}

/* ---------- global events ---------- */
document.addEventListener('click', e => {
  const a = e.target.closest('[data-action]');
  if (a) {
    switch (a.dataset.action) {
      case 'retry': route(); break;
      case 'logout': clearSession(); shellBuilt = false; route.returnTo = ''; toast('You have been signed out.', 'info'); go('/login'); break;
    }
  }
  const btn = $('#user-btn'), menu = $('#user-menu');
  if (btn && menu) {
    if (e.target.closest('#user-btn')) { menu.hidden = !menu.hidden; btn.setAttribute('aria-expanded', String(!menu.hidden)); }
    else if (!e.target.closest('#user-menu')) { menu.hidden = true; btn.setAttribute('aria-expanded', 'false'); }
  }
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { const m = $('#user-menu'); if (m) { m.hidden = true; const b = $('#user-btn'); if (b) b.setAttribute('aria-expanded', 'false'); } }
});
window.addEventListener('hashchange', route);

// Fired by api.js when the token expires (timer, tab return, or pre-request check) or the server answers 401 to a
// request that carried one (authenticateToken() rejecting it).
onUnauthorized(() => {
  const p = parse();
  if (p !== '/login' && p !== '/register') route.returnTo = p;
  shellBuilt = false;
  route.notice = 'Your session has expired. Please sign in again.';
  go('/login');
});

route();
