const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

// Protect admin page
if (!token || !userData) {
    window.location.href = "index.html";
}

const user = JSON.parse(userData);

if (user.role !== "admin") {
    window.location.href = "dashboard.html";
}


// ===============================
// LOAD BOOKINGS
// ===============================

async function loadAdminBookings(status = "") {

    const bookingsGrid =
        document.getElementById("adminBookingsGrid");

    bookingsGrid.innerHTML = "<p>Loading bookings...</p>";

    try {

        let url = "../../bookings.php";

        if (status !== "") {
            url += "?status=" + encodeURIComponent(status);
        }

        const response = await fetch(url);

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "Unable to load bookings.");
        }

        const bookings = data.data || [];

        bookingsGrid.innerHTML = "";

        if (bookings.length === 0) {
            bookingsGrid.innerHTML =
                "<p>No booking records found.</p>";
            return;
        }

        bookings.forEach(function (booking) {

            const card = document.createElement("div");

            card.className = "booking-card";

            card.innerHTML = `
                <div class="booking-top">

                    <div>
                        <p class="booking-id">
                            BOOKING #${booking.id}
                        </p>

                        <h3>
                            ${booking.event_name || "Event Booking"}
                        </h3>
                    </div>

                    <span class="status-badge status-${booking.status}">
                        ${booking.status}
                    </span>

                </div>

                <div class="booking-details">

                    <p>
                        <strong>Customer:</strong>
                        ${booking.customer_name || "Unknown"}
                    </p>

                    <p>
                        <strong>Booking Date:</strong>
                        ${booking.booking_date}
                    </p>

                    <p>
                        <strong>Quantity:</strong>
                        ${booking.quantity}
                    </p>

                    <p>
                        <strong>Total Price:</strong>
                        RM ${Number(booking.total_price).toFixed(2)}
                    </p>

                </div>
                <div class="booking-actions">

    ${
        booking.status === "pending"
        ? `
            <button
                class="confirm-booking-btn"
                onclick="updateBookingStatus(${booking.id}, 'confirmed')">
                Confirm Booking
            </button>

            <button
                class="cancel-booking-btn"
                onclick="updateBookingStatus(${booking.id}, 'cancelled')">
                Cancel Booking
            </button>
        `
        : ""
    }

</div>
            `;

            bookingsGrid.appendChild(card);
        });

    } catch (error) {

        console.error(error);

        bookingsGrid.innerHTML =
            `<p style="color:red;">${error.message}</p>`;
    }
}


// ===============================
// FILTER
// ===============================

document
    .getElementById("statusFilter")
    .addEventListener("change", function () {

        loadAdminBookings(this.value);

    });


// Load all bookings when page opens
loadAdminBookings();

// ===============================
// UPDATE BOOKING STATUS
// ===============================

async function updateBookingStatus(bookingId, newStatus) {

    const confirmAction = confirm(
        `Are you sure you want to ${newStatus} Booking #${bookingId}?`
    );

    if (!confirmAction) {
        return;
    }

    try {

        const response = await fetch(
            `../../bookings.php?id=${bookingId}`,
            {
                method: "PUT",

                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + token
                },

                body: JSON.stringify({
                    status: newStatus
                })
            }
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.error || "Unable to update booking."
            );
        }

        alert(data.message || "Booking updated successfully!");

        loadAdminBookings(
            document.getElementById("statusFilter").value
        );

    } catch (error) {

        console.error(error);

        alert(error.message);
    }
}