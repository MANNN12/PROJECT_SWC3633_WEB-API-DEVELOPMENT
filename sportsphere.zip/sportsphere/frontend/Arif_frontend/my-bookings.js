const API_BASE = "http://localhost/sportsphere";

const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

if (!token || !userData) {
    window.location.href = "index.html";
}

const user = JSON.parse(userData);

const bookingsGrid =
    document.getElementById("bookingsGrid");

const bookingMessage =
    document.getElementById("bookingMessage");


async function loadBookings() {

    try {

        const response =
            await fetch(`${API_BASE}/bookings.php`);

        const result = await response.json();

        if (!response.ok) {
            throw new Error(
                result.error || "Unable to load bookings"
            );
        }

        // Show only logged-in customer's bookings
        const myBookings = result.data.filter(
            booking =>
                Number(booking.customer_id) ===
                Number(user.id)
        );

        bookingMessage.style.display = "none";
        bookingsGrid.innerHTML = "";

        if (myBookings.length === 0) {

            bookingsGrid.innerHTML = `
                <div class="no-bookings">
                    <h3>No bookings yet</h3>
                    <p>
                        You have not made any bookings.
                    </p>

                    <a href="events.html">
                        Browse Events
                    </a>
                </div>
            `;

            return;
        }


        myBookings.forEach(function (booking) {

            const card =
                document.createElement("div");

            card.className = "booking-card";

            card.innerHTML = `

                <div class="booking-top">

                    <div>
                        <p class="booking-id">
                            BOOKING #${booking.id}
                        </p>

                        <h3>
                            ${booking.event_name || "Event Booking"}
                        </h3>
                    </div>

                    <span class="status-badge status-${booking.status}">
                        ${booking.status}
                    </span>

                </div>

                <div class="booking-details">

                    <p>
                        <strong>Booking Date:</strong>
                        ${booking.booking_date}
                    </p>

                    <p>
                        <strong>Quantity:</strong>
                        ${booking.quantity}
                    </p>

                    <p>
                        <strong>Total Price:</strong>
                        RM ${Number(
                            booking.total_price
                        ).toFixed(2)}
                    </p>

                </div>
${booking.status === "pending" ? `
    <button
        class="cancel-booking-btn"
        onclick="cancelBooking(${booking.id})">
        Cancel Booking
    </button>
` : booking.status === "confirmed" ? `
    <button
        class="view-ticket-btn"
        onclick="viewTicket(
            ${booking.id},
            '${booking.event_name || "Event Booking"}',
            '${booking.booking_date}',
            ${booking.quantity},
            ${booking.total_price}
        )">
        View Ticket
    </button>
` : ""}
            `;

            bookingsGrid.appendChild(card);
        });


    } catch (error) {

        console.error(error);

        bookingMessage.style.color = "red";

        bookingMessage.textContent =
            "Unable to load your bookings.";
    }
}

// ===============================
// VIEW TICKET
// ===============================

function viewTicket(
    bookingId,
    eventName,
    bookingDate,
    quantity,
    totalPrice
) {

    window.location.href =
        `ticket.html?booking_id=${bookingId}` +
        `&event=${encodeURIComponent(eventName)}` +
        `&date=${encodeURIComponent(bookingDate)}` +
        `&quantity=${quantity}` +
        `&total=${totalPrice}`;
}

async function cancelBooking(bookingId) {

    const confirmCancel = confirm(
        "Are you sure you want to cancel this booking?"
    );

    if (!confirmCancel) {
        return;
    }

    try {

        const response = await fetch(
            `${API_BASE}/bookings.php?id=${bookingId}`,
            {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify({
                    status: "cancelled"
                })
            }
        );

        const result = await response.json();

        if (response.ok) {
            alert("Booking cancelled successfully.");
            loadBookings();
        } else {
            alert(result.error || "Unable to cancel booking.");
        }

    } catch (error) {
        console.error(error);
        alert("Unable to connect to the server.");
    }
}

// Logout
document
    .getElementById("logoutBtn")
    .addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "index.html";
    });


loadBookings();