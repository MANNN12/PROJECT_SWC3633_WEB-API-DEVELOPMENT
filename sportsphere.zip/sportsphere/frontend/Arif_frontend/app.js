const API_BASE = "http://localhost/sportsphere";

const loginForm = document.getElementById("loginForm");
const loginMessage = document.getElementById("loginMessage");

loginForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    loginMessage.style.color = "#333";
    loginMessage.textContent = "Logging in...";

    try {
        const response = await fetch(`${API_BASE}/auth.php`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                email: email,
                password: password
            })
        });

        const data = await response.json();

        if (response.ok) {
            localStorage.setItem("token", data.token);
            localStorage.setItem("user", JSON.stringify(data.user));

            loginMessage.style.color = "green";
            loginMessage.textContent = "Login successful!";

            // Decide where to go based on the user's role
         let nextPage = "dashboard.html";

if (data.user.role === "admin") {

    nextPage = "admin-dashboard.html";

} else if (data.user.role === "organiser") {

    nextPage = "organiser-dashboard.html";

} else if (data.user.role === "staff") {

    nextPage = "staff-dashboard.html";

}

            setTimeout(function () {
                window.location.href = nextPage;
            }, 800);

        } else {
            loginMessage.style.color = "red";
            loginMessage.textContent =
                data.message ||
                data.error ||
                "Invalid email or password.";
        }

    } catch (error) {
        console.error(error);

        loginMessage.style.color = "red";
        loginMessage.textContent =
            "Unable to connect to the server.";
    }
});