const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

// Check login
if (!token || !userData) {
    window.location.href = "index.html";
} else {
    const user = JSON.parse(userData);

    // Only admin can access this page
    if (user.role !== "admin") {
        window.location.href = "dashboard.html";
    } else {
        document.getElementById("adminName").textContent =
            user.name || "Administrator";
    }
}

// Logout
document.getElementById("logoutBtn").addEventListener("click", function () {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    window.location.href = "index.html";
});

document
    .getElementById("manageEventsBtn")
    .addEventListener("click", function () {
        window.location.href = "admin-events.html";
    });

    document
    .getElementById("manageBookingsBtn")
    .addEventListener("click", function () {
        window.location.href = "admin-bookings.html";
    });

    document
    .getElementById("managePaymentsBtn")
    .addEventListener("click", function () {
        window.location.href = "admin-payments.html";
    });
    document
    .getElementById("manageUsersBtn")
    .addEventListener("click", function () {
        window.location.href = "admin-users.html";
    });