const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

// ===============================
// PROTECT ADMIN PAGE
// ===============================

if (!token || !userData) {
    window.location.href = "index.html";
}

const currentUser = JSON.parse(userData);

if (currentUser.role !== "admin") {
    window.location.href = "dashboard.html";
}


// ===============================
// LOAD USERS
// ===============================

async function loadAdminUsers() {

    const usersGrid =
        document.getElementById("adminUsersGrid");

    usersGrid.innerHTML = "<p>Loading users...</p>";

    try {

        const response = await fetch(
            "../../users.php?page=1&limit=100",
            {
                method: "GET",

                headers: {
                    "Authorization": "Bearer " + token
                }
            }
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.error || "Unable to load users."
            );
        }

        const users = data.data || [];

        displayUsers(users);

    } catch (error) {

        console.error(error);

        usersGrid.innerHTML =
            `<p style="color:red;">${error.message}</p>`;
    }
}


// ===============================
// DISPLAY USERS
// ===============================

function displayUsers(users) {

    const usersGrid =
        document.getElementById("adminUsersGrid");

    usersGrid.innerHTML = "";

    if (users.length === 0) {

        usersGrid.innerHTML =
            "<p>No users found.</p>";

        return;
    }

    users.forEach(function (user) {

        const card = document.createElement("div");

        card.className = "booking-card";
        card.dataset.role = user.role;

        card.innerHTML = `
            <div class="booking-top">

                <div>
                    <p class="booking-id">
                        USER #${user.id}
                    </p>

                    <h3>${user.name}</h3>
                </div>

                <span class="status-badge status-${user.role}">
                    ${user.role}
                </span>

            </div>

            <div class="booking-details">

                <p>
                    <strong>Email:</strong>
                    ${user.email}
                </p>

                <p>
                    <strong>Role:</strong>
                    ${user.role}
                </p>

                <p>
                    <strong>Created:</strong>
                    ${user.created_at}
                </p>

            </div>
           <div class="booking-actions">

    <button
        class="edit-user-btn"
        onclick="editUser(${user.id}, '${user.name}', '${user.role}')"
    >
        Edit User
    </button>

    <button
        class="delete-user-btn"
        onclick="deleteUser(${user.id}, '${user.name}')"
    >
        Delete User
    </button>

</div>
        `;

        usersGrid.appendChild(card);
    });
}


// ===============================
// FILTER BY ROLE
// ===============================

document
    .getElementById("roleFilter")
    .addEventListener("change", function () {

        const selectedRole = this.value;

        const cards =
            document.querySelectorAll(
                "#adminUsersGrid .booking-card"
            );

        cards.forEach(function (card) {

            if (
                selectedRole === "" ||
                card.dataset.role === selectedRole
            ) {
                card.style.display = "";
            } else {
                card.style.display = "none";
            }

        });

    });


// ===============================
// LOGOUT
// ===============================

document
    .getElementById("logoutBtn")
    .addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "index.html";

    });


// Load users when page opens
// ===============================
// EDIT USER
// ===============================

async function editUser(id, currentName, currentRole) {

    const newName = prompt(
        "Enter user name:",
        currentName
    );

    if (newName === null) {
        return;
    }

    if (newName.trim() === "") {
        alert("User name cannot be empty.");
        return;
    }

    const newRole = prompt(
        "Enter role (customer, organiser, staff, admin):",
        currentRole
    );

    if (newRole === null) {
        return;
    }

    const allowedRoles = [
        "customer",
        "organiser",
        "staff",
        "admin"
    ];

    if (!allowedRoles.includes(newRole.toLowerCase())) {
        alert("Invalid role.");
        return;
    }

    try {

        const response = await fetch(
            `../../users.php?id=${id}`,
            {
                method: "PUT",

                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + token
                },

                body: JSON.stringify({
                    name: newName.trim(),
                    role: newRole.toLowerCase()
                })
            }
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.error || "Unable to update user."
            );
        }

        alert("User updated successfully!");

        loadAdminUsers();

    } catch (error) {

        console.error(error);

        alert(error.message);
    }
}
// ===============================
// ADD NEW USER
// ===============================

document
    .getElementById("addUserBtn")
    .addEventListener("click", async function () {

        const name =
            document.getElementById("newUserName").value.trim();

        const email =
            document.getElementById("newUserEmail").value.trim();

        const password =
            document.getElementById("newUserPassword").value;

        const role =
            document.getElementById("newUserRole").value;

        const message =
            document.getElementById("addUserMessage");


        // Validation
        if (!name || !email || !password || !role) {
            message.style.color = "red";
            message.textContent =
                "Please complete all fields.";
            return;
        }


        try {

            message.style.color = "#64748b";
            message.textContent = "Creating user...";

            const response = await fetch(
                "../../users.php",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + token
                    },

                    body: JSON.stringify({
                        name: name,
                        email: email,
                        password: password,
                        role: role
                    })
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(
                    data.error || "Unable to create user."
                );
            }


            message.style.color = "green";
            message.textContent =
                "User created successfully!";


            // Clear form
            document.getElementById("newUserName").value = "";
            document.getElementById("newUserEmail").value = "";
            document.getElementById("newUserPassword").value = "";
            document.getElementById("newUserRole").value = "customer";


            // Refresh user list
            await loadAdminUsers();

        } catch (error) {

            console.error(error);

            message.style.color = "red";
            message.textContent = error.message;
        }

    });
    // ===============================
// DELETE USER
// ===============================

async function deleteUser(id, name) {

    const confirmDelete = confirm(
        `Are you sure you want to delete ${name}?`
    );

    if (!confirmDelete) {
        return;
    }

    try {

        const response = await fetch(
            `../../users.php?id=${id}`,
            {
                method: "DELETE",

                headers: {
                    "Authorization": "Bearer " + token
                }
            }
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(
                data.error || "Unable to delete user."
            );
        }

        alert("User deleted successfully!");

        // Refresh user list
        await loadAdminUsers();

    } catch (error) {

        console.error(error);

        alert(error.message);
    }
}
loadAdminUsers();