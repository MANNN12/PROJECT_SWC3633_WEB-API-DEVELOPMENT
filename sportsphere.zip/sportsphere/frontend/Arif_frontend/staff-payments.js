const API_BASE = "http://localhost/sportsphere";

const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

// ===============================
// CHECK LOGIN
// ===============================

if (!token || !userData) {
    window.location.href = "index.html";
}

const currentUser = JSON.parse(userData);


// ===============================
// PROTECT STAFF PAGE
// ===============================

if (currentUser.role !== "staff") {

    if (currentUser.role === "admin") {
        window.location.href = "admin-dashboard.html";

    } else if (currentUser.role === "organiser") {
        window.location.href = "organiser-dashboard.html";

    } else {
        window.location.href = "dashboard.html";
    }
}


// Store payment records
let allPayments = [];


// ===============================
// LOAD PAYMENTS
// ===============================

async function loadPayments() {

    const paymentsGrid =
        document.getElementById("paymentsGrid");

    paymentsGrid.innerHTML =
        "<p>Loading payments...</p>";

    try {

        const response = await fetch(
            `${API_BASE}/payments.php`,
            {
                method: "GET",

                headers: {
                    "Authorization": `Bearer ${token}`
                }
            }
        );

        const result = await response.json();

        if (!response.ok) {
            throw new Error(
                result.error ||
                "Unable to load payments."
            );
        }

        allPayments = result.data || result;

        displayPayments(allPayments);

    } catch (error) {

        console.error(error);

        paymentsGrid.innerHTML = `
            <p style="color:red;">
                ${error.message}
            </p>
        `;
    }
}


// ===============================
// DISPLAY PAYMENTS
// ===============================

function displayPayments(payments) {

    const paymentsGrid =
        document.getElementById("paymentsGrid");

    paymentsGrid.innerHTML = "";


    if (!payments || payments.length === 0) {

        paymentsGrid.innerHTML =
            "<p>No payment records found.</p>";

        return;
    }


    payments.forEach(function (payment) {
       
        console.log("PAYMENT DATA:", payment);

        const status =
            payment.payment_status || "pending";

        const card =
            document.createElement("div");

        card.className = "booking-card";


        card.innerHTML = `

            <div class="booking-top">

                <div>

                    <p class="booking-id">
                        PAYMENT #${payment.id}
                    </p>

                    <h3>
                        Booking #${payment.booking_id}
                    </h3>

                </div>


                <span class="status-badge status-${status}">
                    ${status.toUpperCase()}
                </span>

            </div>


            <div class="booking-details">

                <p>
                    <strong>Amount:</strong>
                    RM ${Number(
                        payment.amount || 0
                    ).toFixed(2)}
                </p>

                <p>
                    <strong>Payment Method:</strong>
                    ${formatPaymentMethod(
                        payment.payment_method
                    )}
                </p>

                <p>
                    <strong>Transaction Reference:</strong>
                    ${payment.transaction_ref || "N/A"}
                </p>

                <p>
                    <strong>Payment Date:</strong>
                    ${payment.created_at || "N/A"}
                </p>

            </div>

        `;


        paymentsGrid.appendChild(card);

    });
}


// ===============================
// FORMAT PAYMENT METHOD
// ===============================

function formatPaymentMethod(method) {

    if (!method) {
        return "N/A";
    }

    if (method === "fpx") {
        return "FPX";
    }

    if (method === "card") {
        return "Card";
    }

    if (method === "e-wallet") {
        return "E-Wallet";
    }

    return method;
}


// ===============================
// FILTER PAYMENT STATUS
// ===============================

document
    .getElementById("paymentStatusFilter")
    .addEventListener("change", function () {

        const selectedStatus =
            this.value;


        if (selectedStatus === "all") {

            displayPayments(allPayments);

            return;
        }


        const filteredPayments =
            allPayments.filter(function (payment) {

                return (
                    payment.payment_status ===
                    selectedStatus
                );

            });


        displayPayments(filteredPayments);

    });


// ===============================
// LOGOUT
// ===============================

document
    .getElementById("logoutBtn")
    .addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "index.html";

    });


// ===============================
// LOAD PAGE
// ===============================

loadPayments();