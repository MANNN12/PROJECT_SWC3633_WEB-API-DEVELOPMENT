const API_BASE = "http://localhost/sportsphere";

const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

// ===============================
// CHECK LOGIN
// ===============================

if (!token || !userData) {
    window.location.href = "index.html";
}

const currentUser = JSON.parse(userData);


// ===============================
// PROTECT ORGANISER PAGE
// ===============================

if (currentUser.role !== "organiser") {

    if (currentUser.role === "admin") {
        window.location.href = "admin-dashboard.html";

    } else if (currentUser.role === "staff") {
        window.location.href = "staff-dashboard.html";

    } else {
        window.location.href = "dashboard.html";
    }
}


// Store bookings
let allBookings = [];


// ===============================
// LOAD BOOKINGS
// ===============================

async function loadBookings() {

    const bookingsGrid =
        document.getElementById("bookingsGrid");

    bookingsGrid.innerHTML =
        "<p>Loading bookings...</p>";

    try {

        const response = await fetch(
            `${API_BASE}/bookings.php`
        );

        const result = await response.json();

        if (!response.ok) {
            throw new Error(
                result.error ||
                "Unable to load bookings."
            );
        }

        allBookings = result.data || result;

        displayBookings(allBookings);

    } catch (error) {

        console.error(error);

        bookingsGrid.innerHTML = `
            <p style="color:red;">
                ${error.message}
            </p>
        `;
    }
}


// ===============================
// DISPLAY BOOKINGS
// ===============================

function displayBookings(bookings) {

    const bookingsGrid =
        document.getElementById("bookingsGrid");

    bookingsGrid.innerHTML = "";


    if (!bookings || bookings.length === 0) {

        bookingsGrid.innerHTML =
            "<p>No bookings found.</p>";

        return;
    }


    bookings.forEach(function (booking) {

        const card =
            document.createElement("div");

        card.className = "booking-card";


        const status =
            booking.status || "pending";


        card.innerHTML = `

            <div class="booking-top">

                <div>

                    <p class="booking-id">
                        BOOKING #${booking.id}
                    </p>

                    <h3>
                        ${booking.event_name || "Event Booking"}
                    </h3>

                </div>


                <span class="status-badge status-${status}">
                    ${status.toUpperCase()}
                </span>

            </div>


            <div class="booking-details">

                <p>
                    <strong>Customer:</strong>
                    ${booking.customer_name || "N/A"}
                </p>

                <p>
                    <strong>Booking Date:</strong>
                    ${booking.booking_date || "N/A"}
                </p>

                <p>
                    <strong>Quantity:</strong>
                    ${booking.quantity || 0}
                </p>

                <p>
                    <strong>Total Price:</strong>
                    RM ${Number(
                        booking.total_price || 0
                    ).toFixed(2)}
                </p>

            </div>

        `;


        bookingsGrid.appendChild(card);

    });
}


// ===============================
// FILTER BOOKINGS
// ===============================

document
    .getElementById("statusFilter")
    .addEventListener("change", function () {

        const selectedStatus =
            this.value;


        if (selectedStatus === "all") {

            displayBookings(allBookings);

            return;
        }


        const filteredBookings =
            allBookings.filter(function (booking) {

                return booking.status === selectedStatus;

            });


        displayBookings(filteredBookings);

    });


// ===============================
// LOGOUT
// ===============================

document
    .getElementById("logoutBtn")
    .addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "index.html";

    });


// ===============================
// LOAD PAGE
// ===============================

loadBookings();