const API_BASE = "http://localhost/sportsphere";

const registerForm =
    document.getElementById("registerForm");

const registerMessage =
    document.getElementById("registerMessage");


// ===============================
// REGISTER NEW CUSTOMER
// ===============================

registerForm.addEventListener(
    "submit",
    async function (event) {

        event.preventDefault();


        const name =
            document
                .getElementById("registerName")
                .value
                .trim();

        const email =
            document
                .getElementById("registerEmail")
                .value
                .trim();

        const password =
            document
                .getElementById("registerPassword")
                .value;

        const confirmPassword =
            document
                .getElementById("confirmPassword")
                .value;


        // ===============================
        // VALIDATION
        // ===============================

        if (
            !name ||
            !email ||
            !password ||
            !confirmPassword
        ) {

            showMessage(
                "Please complete all fields.",
                "red"
            );

            return;
        }


        if (password.length < 6) {

            showMessage(
                "Password must be at least 6 characters.",
                "red"
            );

            return;
        }


        if (password !== confirmPassword) {

            showMessage(
                "Passwords do not match.",
                "red"
            );

            return;
        }


        // ===============================
        // SEND TO USERS API
        // ===============================

        try {

            showMessage(
                "Creating your account...",
                "#64748b"
            );


            const response = await fetch(
                `${API_BASE}/users.php`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({

                        name: name,

                        email: email,

                        password: password,

                        // Public registration is
                        // always CUSTOMER
                        role: "customer"

                    })
                }
            );


            const result =
                await response.json();


            if (!response.ok) {

                throw new Error(
                    result.error ||
                    result.message ||
                    "Unable to create account."
                );

            }


            // ===============================
            // SUCCESS
            // ===============================

            showMessage(
                "Account created successfully! Redirecting to login...",
                "green"
            );


            registerForm.reset();


            setTimeout(function () {

                window.location.href =
                    "index.html";

            }, 1500);


        } catch (error) {

            console.error(error);

            showMessage(
                error.message,
                "red"
            );

        }

    }
);


// ===============================
// MESSAGE FUNCTION
// ===============================

function showMessage(message, color) {

    registerMessage.style.color =
        color;

    registerMessage.textContent =
        message;

}