const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

// ===============================
// CHECK LOGIN
// ===============================

if (!token || !userData) {
    window.location.href = "index.html";
}

const user = JSON.parse(userData);


// ===============================
// GET TICKET INFORMATION
// ===============================

const params = new URLSearchParams(window.location.search);

const bookingId = params.get("booking_id");
const eventName = params.get("event");
const bookingDate = params.get("date");
const quantity = params.get("quantity");
const totalPrice = params.get("total");

const ticketDetails =
    document.getElementById("ticketDetails");


// ===============================
// DISPLAY TICKET
// ===============================

if (
    !bookingId ||
    !eventName ||
    !bookingDate ||
    !quantity ||
    !totalPrice
) {

    ticketDetails.innerHTML = `
        <p style="color:red;">
            Ticket information is incomplete.
        </p>
    `;

} else {

    ticketDetails.innerHTML = `
        <div class="booking-card">

            <div class="booking-top">

                <div>
                    <p class="booking-id">
                        E-TICKET #${bookingId}
                    </p>

                    <h2>${eventName}</h2>
                </div>

                <span class="status-badge status-confirmed">
                    CONFIRMED
                </span>

            </div>

            <div class="booking-details">

                <p>
                    <strong>Customer:</strong>
                    ${user.name}
                </p>

                <p>
                    <strong>Booking ID:</strong>
                    #${bookingId}
                </p>

                <p>
                    <strong>Event Date:</strong>
                    ${bookingDate}
                </p>

                <p>
                    <strong>Quantity:</strong>
                    ${quantity} ticket(s)
                </p>

                <p>
                    <strong>Total Price:</strong>
                    RM ${Number(totalPrice).toFixed(2)}
                </p>

            </div>

        </div>
    `;
}
// ===============================
// GENERATE QR CODE
// ===============================

const qrData =
    `SportSphere Ticket\n` +
    `Booking ID: ${bookingId}\n` +
    `Event: ${eventName}\n` +
    `Customer: ${user.name}\n` +
    `Event Date: ${bookingDate}\n` +
    `Quantity: ${quantity}`;

const qrCodeUrl =
    "https://api.qrserver.com/v1/create-qr-code/" +
    "?size=220x220" +
    "&data=" + encodeURIComponent(qrData);

document.getElementById("qrCodeContainer").innerHTML = `
    <div class="ticket-qr">

        <h3>Ticket QR Code</h3>

        <img
            src="${qrCodeUrl}"
            alt="SportSphere Ticket QR Code"
            width="220"
            height="220"
        >

        <p>
            Scan this QR code to verify ticket information.
        </p>

    </div>
`;


// ===============================
// LOGOUT
// ===============================

document
    .getElementById("logoutBtn")
    .addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "index.html";

    });