const API_BASE = "http://localhost/sportsphere";

const token = localStorage.getItem("token");
const userData = localStorage.getItem("user");

if (!token || !userData) {
    window.location.href = "index.html";
}

const user = JSON.parse(userData);

const params = new URLSearchParams(window.location.search);
const eventId = params.get("id");

const eventDetails = document.getElementById("eventDetails");

let currentEvent = null;


// Load selected event
async function loadEventDetails() {

    if (!eventId) {
        eventDetails.innerHTML =
            "<p>Event ID is missing.</p>";
        return;
    }

    try {

        const response = await fetch(
            `${API_BASE}/events.php?id=${eventId}`
        );

        const result = await response.json();

        if (!response.ok) {
            throw new Error(
                result.error || "Unable to load event"
            );
        }

        currentEvent = result.data;

        const ticketsAvailable =
            Number(currentEvent.total_tickets) -
            Number(currentEvent.tickets_sold);

        eventDetails.innerHTML = `
            <div class="details-icon">🏆</div>

            <p class="welcome-label">EVENT DETAILS</p>

            <h1>${currentEvent.event_name}</h1>

            <div class="details-info">

                <div>
                    <span>Event Date</span>
                    <strong>${currentEvent.event_date}</strong>
                </div>

                <div>
                    <span>Ticket Price</span>
                    <strong>
                        RM ${Number(
                            currentEvent.ticket_price
                        ).toFixed(2)}
                    </strong>
                </div>

                <div>
                    <span>Tickets Available</span>
                    <strong>${ticketsAvailable}</strong>
                </div>

            </div>

            <hr>

            <div class="booking-section">

                <h2>Book Your Ticket</h2>

                <label for="quantity">
                    Number of Tickets
                </label>

                <input
                    type="number"
                    id="quantity"
                    min="1"
                    max="${ticketsAvailable}"
                    value="1"
                >

                <div class="booking-total">
                    Total:
                    <strong id="totalPrice">
                        RM ${Number(
                            currentEvent.ticket_price
                        ).toFixed(2)}
                    </strong>
                </div>

                <button id="bookNowBtn">
                    Book Now
                </button>

                <p id="bookingMessage"></p>

            </div>
        `;

        const quantityInput =
            document.getElementById("quantity");

        quantityInput.addEventListener(
            "input",
            updateTotal
        );

        document
            .getElementById("bookNowBtn")
            .addEventListener(
                "click",
                createBooking
            );

    } catch (error) {

        console.error(error);

        eventDetails.innerHTML =
            `<p class="error-message">
                Unable to load event details.
            </p>`;
    }
}


// Update total when quantity changes
function updateTotal() {

    const quantity =
        Number(
            document.getElementById("quantity").value
        );

    const total =
        Number(currentEvent.ticket_price) * quantity;

    document.getElementById(
        "totalPrice"
    ).textContent = `RM ${total.toFixed(2)}`;
}


// Create booking using bookings.php
async function createBooking() {

    const quantity =
        Number(
            document.getElementById("quantity").value
        );

    const message =
        document.getElementById("bookingMessage");

    if (quantity < 1) {
        message.style.color = "red";
        message.textContent =
            "Please enter a valid quantity.";
        return;
    }
if (quantity > currentEvent.total_tickets) {
    message.style.color = "red";
    message.textContent =
        `Only ${currentEvent.total_tickets} tickets are available.`;
    return;
}
    message.style.color = "#64748b";
    message.textContent = "Processing booking...";

    try {

        const response = await fetch(
            `${API_BASE}/bookings.php`,
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },

                body: JSON.stringify({
                    customer_id: user.id,
                    booking_type: "event",
                    event_id: Number(eventId),
                    booking_date: currentEvent.event_date,
                    quantity: quantity,
                    status: "pending"
                })
            }
        );

        const result = await response.json();

       if (response.ok) {

    message.style.color = "green";

    message.textContent =
        "Booking created successfully! Redirecting to payment...";

    const totalAmount =
        Number(currentEvent.ticket_price) * quantity;

    setTimeout(function () {

        window.location.href =
            `payment.html?booking_id=${result.booking_id}` +
            `&amount=${totalAmount.toFixed(2)}` +
            `&event=${encodeURIComponent(currentEvent.event_name)}` +
            `&quantity=${quantity}`;

    }, 1000);

} else {

            message.style.color = "red";

            message.textContent =
                result.error ||
                "Unable to create booking.";
        }

    } catch (error) {

        console.error(error);

        message.style.color = "red";

        message.textContent =
            "Unable to connect to the server.";
    }
}


// Logout
document
    .getElementById("logoutBtn")
    .addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "index.html";
    });


loadEventDetails();