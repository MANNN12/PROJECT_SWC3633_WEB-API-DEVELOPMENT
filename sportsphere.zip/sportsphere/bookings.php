<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/api_helpers.php';

jsonHeaders(['GET', 'POST', 'PUT', 'DELETE']);
$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? validId($_GET['id']) : null;

if ($method === 'GET') {
    $page = isset($_GET['page']) ? validId($_GET['page']) : null;
    $limit = isset($_GET['limit']) ? validId($_GET['limit']) : null;
    $status = $_GET['status'] ?? null;

    $query = 'SELECT b.*, u.name AS customer_name, v.venue_name, e.event_name 
              FROM bookings b 
              LEFT JOIN users u ON b.customer_id = u.id 
              LEFT JOIN venues v ON b.venue_id = v.id 
              LEFT JOIN events e ON b.event_id = e.id ';

    if ($id !== null) {
        $stmt = $conn->prepare($query . ' WHERE b.id = ?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $booking = $stmt->get_result()->fetch_assoc();
        if (!$booking) respond(404, ['error' => 'Booking not found']);
        respond(200, ['data' => $booking]);
    }

    // Return all records if pagination is not specified (suited for UI tables)
    if ($page === null || $limit === null) {
        if ($status) {
            $stmt = $conn->prepare($query . ' WHERE b.status = ? ORDER BY b.id DESC');
            $stmt->bind_param('s', $status);
        } else {
            $stmt = $conn->prepare($query . ' ORDER BY b.id DESC');
        }
        $stmt->execute();
        $bookings = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

        respond(200, ['data' => $bookings]);
    }

    // Fixed PHP offset calculation
    $offset = ($page - 1) * $limit;

    if ($status) {
        $stmt = $conn->prepare($query . ' WHERE b.status = ? ORDER BY b.id DESC LIMIT ? OFFSET ?');
        $stmt->bind_param('sii', $status, $limit, $offset);
    } else {
        $stmt = $conn->prepare($query . ' ORDER BY b.id DESC LIMIT ? OFFSET ?');
        $stmt->bind_param('ii', $limit, $offset);
    }

    $stmt->execute();
    $bookings = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    respond(200, [
        'page' => $page,
        'limit' => $limit,
        'data' => $bookings
    ]);
}

if ($method === 'POST') {
    $currentUser = authenticateToken();

    $data = readJson();
    $custId = validId($data['customer_id'] ?? null);
    $type = trim($data['booking_type'] ?? '');
    $venueId = validId($data['venue_id'] ?? null);
    $eventId = validId($data['event_id'] ?? null);
    $date = trim($data['booking_date'] ?? '');
    $qty = validId($data['quantity'] ?? 1);
    
    // Default to 'pending' if no status provided, otherwise accept valid status
    $status = trim($data['status'] ?? 'pending');
    if (!in_array($status, ['pending', 'confirmed', 'cancelled'])) {
        $status = 'pending';
    }

    if (!$custId || !in_array($type, ['venue', 'event']) || empty($date)) {
        respond(422, ['error' => 'Invalid booking parameters provided']);
    }

    $totalPrice = 0.00;
    if ($type === 'venue') {
        if (!$venueId) respond(422, ['error' => 'venue_id parameter is required']);
        $v = $conn->query("SELECT hourly_rate, is_available FROM venues WHERE id = {$venueId}")->fetch_assoc();
        if (!$v || !$v['is_available']) respond(422, ['error' => 'Selected venue is unavailable']);
        $totalPrice = (float)$v['hourly_rate'] * $qty;
    } else {
        if (!$eventId) respond(422, ['error' => 'event_id parameter is required']);
        $e = $conn->query("SELECT ticket_price FROM events WHERE id = {$eventId}")->fetch_assoc();
        if (!$e) respond(422, ['error' => 'Selected event does not exist']);
        $totalPrice = (float)$e['ticket_price'] * $qty;
    }

    // Generate QR code ticket only when status is confirmed
    $qrUrl = null;
    if ($status === 'confirmed') {
        $qrString = "SPORTSPHERE-BOOKING-CUST{$custId}-DATE{$date}-PRICE{$totalPrice}";
        $qrUrl = generateQRCode($qrString);
    }

    $stmt = $conn->prepare('INSERT INTO bookings (customer_id, venue_id, event_id, booking_type, booking_date, quantity, total_price, status, qr_code_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->bind_param('iiissidss', $custId, $venueId, $eventId, $type, $date, $qty, $totalPrice, $status, $qrUrl);
    $stmt->execute();

    respond(201, [
        'message' => 'Booking created successfully',
        'booking_id' => $conn->insert_id,
        'status' => $status,
        'qr_code_url' => $qrUrl
    ]);
}

if ($method === 'PUT') {
    $currentUser = authenticateToken();
    authorizeRoles(['admin', 'staff'], $currentUser);

    if ($id === null) respond(400, ['error' => 'Booking ID is required']);

    $data = readJson();
    $status = trim($data['status'] ?? '');

    if (!in_array($status, ['pending', 'confirmed', 'cancelled'])) {
        respond(422, ['error' => 'Invalid status value']);
    }

    // If staff confirms booking, generate QR code dynamically if not existing
    if ($status === 'confirmed') {
        $b = $conn->query("SELECT customer_id, booking_date, total_price FROM bookings WHERE id = {$id}")->fetch_assoc();
        if ($b) {
            $qrString = "SPORTSPHERE-BOOKING-CUST{$b['customer_id']}-DATE{$b['booking_date']}-PRICE{$b['total_price']}";
            $qrUrl = generateQRCode($qrString);
            $stmt = $conn->prepare('UPDATE bookings SET status = ?, qr_code_url = ? WHERE id = ?');
            $stmt->bind_param('ssi', $status, $qrUrl, $id);
            $stmt->execute();
            respond(200, ['message' => 'Booking confirmed and QR Ticket generated successfully', 'qr_code_url' => $qrUrl]);
        }
    }

    // Handle 'cancelled' or 'pending' statuses
    $stmt = $conn->prepare('UPDATE bookings SET status = ?, qr_code_url = NULL WHERE id = ?');
    $stmt->bind_param('si', $status, $id);
    $stmt->execute();

    respond(200, ['message' => 'Booking status updated successfully']);
}

if ($method === 'DELETE') {
    $currentUser = authenticateToken();
    authorizeRoles(['admin'], $currentUser);

    if ($id === null) respond(400, ['error' => 'Booking ID is required']);

    $stmt = $conn->prepare('DELETE FROM bookings WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();

    respond(200, ['message' => 'Booking record deleted successfully']);
}

respond(405, ['error' => 'Method Not Allowed']);