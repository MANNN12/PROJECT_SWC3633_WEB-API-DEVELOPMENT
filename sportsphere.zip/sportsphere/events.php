<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/api_helpers.php';

jsonHeaders(['GET', 'POST', 'PUT', 'DELETE']);
$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? validId($_GET['id']) : null;

if ($method === 'GET') {
    if ($id !== null) {
        $stmt = $conn->prepare('
            SELECT e.*, 
                   COALESCE(SUM(b.quantity), 0) AS tickets_sold 
            FROM events e 
            LEFT JOIN bookings b ON e.id = b.event_id AND b.status != "cancelled"
            WHERE e.id = ?
            GROUP BY e.id
        ');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $event = $stmt->get_result()->fetch_assoc();
        if (!$event) respond(404, ['error' => 'Event not found']);
        respond(200, ['data' => $event]);
    }

    $sql = '
        SELECT e.*, 
               COALESCE(SUM(b.quantity), 0) AS tickets_sold 
        FROM events e 
        LEFT JOIN bookings b ON e.id = b.event_id AND b.status != "cancelled"
        GROUP BY e.id 
        ORDER BY e.id DESC
    ';
    $result = $conn->query($sql);
    respond(200, ['data' => $result->fetch_all(MYSQLI_ASSOC)]);
}

if ($method === 'POST') {
    $currentUser = authenticateToken();
    authorizeRoles(['admin', 'organiser'], $currentUser);

    $data = readJson();
    $name = trim($data['event_name'] ?? '');
    $orgId = validId($data['organiser_id'] ?? null);
    $date = trim($data['event_date'] ?? '');
    $price = filter_var($data['ticket_price'] ?? null, FILTER_VALIDATE_FLOAT);
    $tickets = validId($data['total_tickets'] ?? null);

    if (empty($name) || !$orgId || empty($date) || $price === false || !$tickets) {
        respond(422, ['error' => 'Invalid or missing event data inputs']);
    }

    $stmt = $conn->prepare('INSERT INTO events (event_name, organiser_id, event_date, ticket_price, total_tickets) VALUES (?, ?, ?, ?, ?)');
    $stmt->bind_param('sisdi', $name, $orgId, $date, $price, $tickets);
    $stmt->execute();

    respond(201, ['message' => 'Event published successfully', 'id' => $conn->insert_id]);
}

if ($method === 'PUT') {
    $currentUser = authenticateToken();
    authorizeRoles(['admin', 'organiser'], $currentUser);

    if ($id === null) respond(400, ['error' => 'Event ID is required']);

    $data = readJson();
    $name = trim($data['event_name'] ?? '');
    $price = filter_var($data['ticket_price'] ?? null, FILTER_VALIDATE_FLOAT);

    $stmt = $conn->prepare('UPDATE events SET event_name = ?, ticket_price = ? WHERE id = ?');
    $stmt->bind_param('sdi', $name, $price, $id);
    $stmt->execute();

    respond(200, ['message' => 'Event updated successfully']);
}

if ($method === 'DELETE') {
    $currentUser = authenticateToken();
    authorizeRoles(['admin', 'organiser'], $currentUser);

    if ($id === null) respond(400, ['error' => 'Event ID is required']);

    $stmt = $conn->prepare('DELETE FROM events WHERE id = ?');
    $stmt->bind_param('i', $id);
    $stmt->execute();

    respond(200, ['message' => 'Event canceled and deleted']);
}

respond(405, ['error' => 'Method Not Allowed']);