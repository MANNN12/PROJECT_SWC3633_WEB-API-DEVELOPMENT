<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/api_helpers.php';

jsonHeaders(['GET', 'POST']);
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $currentUser = authenticateToken();
    authorizeRoles(['admin', 'staff'], $currentUser);

    $result = $conn->query('SELECT * FROM payments ORDER BY id DESC');
    respond(200, ['data' => $result->fetch_all(MYSQLI_ASSOC)]);
}

if ($method === 'POST') {
    $currentUser = authenticateToken();

    $data = readJson();
    $bookingId = validId($data['booking_id'] ?? null);
    $paymentMethod = trim($data['payment_method'] ?? '');
    $amount = filter_var($data['amount'] ?? null, FILTER_VALIDATE_FLOAT);

    if (!$bookingId || !in_array($paymentMethod, ['fpx', 'card', 'e-wallet']) || $amount === false) {
        respond(422, ['error' => 'Invalid payment payload parameters']);
    }

    $txnRef = 'TXN' . rand(10000, 99999);
    $status = 'completed';

    $stmt = $conn->prepare('INSERT INTO payments (booking_id, payment_method, amount, payment_status, transaction_ref) VALUES (?, ?, ?, ?, ?)');
    $stmt->bind_param('isdss', $bookingId, $paymentMethod, $amount, $status, $txnRef);
    $stmt->execute();

    respond(201, [
        'message' => 'Payment processed successfully',
        'transaction_ref' => $txnRef
    ]);
}

respond(405, ['error' => 'Method Not Allowed']);